(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
(() => {

	'use strict';

	/**
	 * @summary The api for searching terms, images, and articles on Wikipedia.
	 */
	class WikipediaAPI {
		constructor() { }

		/**
		 * @summary Searches an image on Wikipedia by given term and size.
		 * @param {object} options
		 * @param {string} options.term The term to be searched for.
		 * @param {number} options.size The height in pixels of the image;
		 * @returns {Promise<WikipediaImage>} Returns a promise that resolves to an object with url, width, and height properties.
		 */
		searchImage({ term, size }) {
			return new Promise(resolve => {
				chrome.runtime.sendMessage({ provider: 'wp', request: 'searchImage', args: [term, "en", size] }, resolve);
			});

		}

		/**
		 * @summary Searchs a single page on Wikipedia containing given term.
		 * @param {Object} options
		 * @param {string} options.term The full or partial article title to be searched for.
		 * @param {string} [options.range] A set of words in the same language as the term.
		 * @returns {Promise<{WikipediaPage}>} Returns a promise tha resolves to an object `WikipediaPage`.
		 */
		searchTerm({ range = '', term = '' }) {

			return new Promise(resolve => {
				chrome.runtime.sendMessage({ provider: 'wp', request: 'searchTitle', args: [term, "en", 50] }, resolve);
			});
		}

		/**
		 * @summary Searchs a single page on Wikipedia containing given id.
		 * @param {object} options
		 * @param {number|string} options.pageId The id of the article page.
		 * @param {string} [options.language=en] A set of words in the same language as the term.
		 * @param {number|string} [options.imageSize=250] The height of the article's image, in pixel.
		 * @returns {Promise<{WikipediaPage}>} Returns a promise tha resolves to an object `WikipediaPage`.
		 */
		getPageById({ pageId, language = 'en', imageSize = 250 }) {
			return new Promise(resolve => {
				chrome.runtime.sendMessage({ provider: 'wp', request: 'getPageById', args: [pageId, language, imageSize] }, resolve);
			});
		}

		/**
		 * @summary Searchs a list of pages containing given term.
		 * @param {object} options
		 * @param {string} [options.range] A set of words in the same language as the term.
		 * @param {string} options.term The full or partial article title to be searched for.
		 * @returns {Promise<{WikipediaThumbnail}>} Returns a promise tha resolves to an object `WikipediaThumbnail`.
		 */
		getPageList({ range = '', term }) {
			return new Promise(resolve => {
				chrome.runtime.sendMessage({ provider: 'wp', request: 'searchResults', args: [term, "en"] }, resolve);
			});
		}
	}

	module.exports = new WikipediaAPI();

})();
},{}],2:[function(require,module,exports){
(() => {
	'use strict';

	class WiktionaryAPI {
		constructor() {
			this.getDefinitions = this.searchTerm;
		}

		/**
		 * @summary It searches a given term on wiktionary.
		 * @param {String} obj.term The term to be searched on wiktionary.
		 * @returns {Promise.<object>} Returns a Promise that resolves to an object with ....
		 */
		searchTerm(term = '') {
			return new Promise(async resolve => {
				chrome.runtime.sendMessage({ provider: 'wt', request: 'searchTitle', args: term }, resolve);
			});
		}
	}

	module.exports = new WiktionaryAPI();

})();
},{}],3:[function(require,module,exports){
(() => {
    'use strict';

    module.exports = { getBasicShell };


	/**
	 * Generates the popover main structure without any data.
	 * @returns {DocumentFragment} A popover documentFragment.
	 */
    function getBasicShell(callback) {

        const popover = document.querySelector("#popover");

        insertThumbnails(popover, blankThumbnails());

        popover.querySelectorAll('.js-infoSect').forEach(section => section.classList.add('hidden'));
        popover.querySelector('.js-wikiSearches').classList.remove('hidden');

        if (!callback)
            return popover;

        return callback(popover);
    }

    ////////////////// IMPLEMENTATION //////////////////

    function insertThumbnails(popover, thumbnails) {

        popover.querySelector('.js-wikiSearches').appendChild(thumbnails);

        return popover;
    }

	/**
	 * Generates blank thumbnails to use as placeholders while the content is being loaded.
	 * @param {number} quantity The quantity of thumbnails.
	 */
    function blankThumbnails(quantity = 6) {

        var fragment = document.createDocumentFragment();
        var template = document.querySelector("#blankThumbnails");

        for (let i = 0; i < quantity; i++) {

            var clonedTemplate = template.content.cloneNode(true);
            fragment.appendChild(clonedTemplate);
        }

        return fragment;
    }

})();
},{}],4:[function(require,module,exports){
(() => {
	'use strict';

	module.exports = popoverManager;

	/**
	 * A popover DOM management API
	 * @param {HTMLElement} popover 
	 */
	function popoverManager(popover) {

		/**
		 * The Popover element used in the manager dispatches some events:
		 * - "tabselect" - When the user clicks on a tab (List, Wikipedia, or Wiktionary),
		 * - "popoverHidden" - When the popover has finished the hidden process,
		 * - "thumbclick" - When the user selects an article of the search response list,
		 * - "pagechange" - When a change of page occurs, independent of the trigger,
		 */
		class Popover {
			constructor(popover) {

				if (!popover)
					throw new ReferenceError('It is required to indicate a popover element for this function to work properly.')

				if (!(popover instanceof HTMLElement))
					throw new TypeError('The given popover is not a instance of HTMLElement');


				this.HTMLElement = popover;
				this.sections = this.popoverElements();
				this.hide = hidePopover;
				this.render = appendPopover;
				this.setThumbnails = this.insertThumbnails;
				this.setArticle = insertArticle;
				this.setDictionary = insertDictionary;
				this.isLoading = insertBlankData;
				this.isChild = isPopoverChild;
				this.showPage = showPage;
				this.addEventListener = (eventName, eventListener) => popover.addEventListener(eventName, eventListener);

				this.createCustomEvents();
				popover.addEventListener('tabselect', ev => showPage(ev.detail.target, !isDisabled(ev.detail.element)));
				popover.addEventListener('popoverHidden', ev => disableTab(1));
				popover.addEventListener('thumbclick', ev => enableTab(1));
				popover.addEventListener('pagechange', ev => {
					if (ev.detail.element === this.sections.wikipediaWrapper || ev.detail.element === this.sections.wiktionaryWrapper) {
						showElements(this.sections.resultsTab);
					} else {
						hideElements(this.sections.resultsTab);
					}
				});
			}

			insertThumbnails(thumbs = []) {
				if (!thumbs.length) {
					popover = setThumbsError();
				} else {
					const thumbsSect = popover.querySelector('.js-wikiSearches');
					const thumbnails = thumbnailsToHtml(thumbs);

					thumbnails.querySelectorAll('.js-item').forEach(thumbnail => {
						if (thumbnail) {
							let thumbnailClick = new CustomEvent('thumbclick', {
								bubbles: true,
								detail: {
									article: {
										id: thumbnail.id,
										lang: thumbnail.attributes.getNamedItem('lang').value,
										title: thumbnail.querySelector('.js-title').textContent
									}
								}
							});

							thumbnail.addEventListener('click', ev => popover.dispatchEvent(thumbnailClick));
						}
					});

					removeChildrenFrom(thumbsSect);
					thumbsSect.appendChild(thumbnails);
				}

				return popover;
			}

			popoverElements() {

				return {
					resultsTab: popover.querySelector('.js-listTab'),
					wikiTab: popover.querySelector('.js-wikiTab'),
					wiktTab: popover.querySelector('.js-wiktTab'),
					listWrapper: popover.querySelector('.js-wikiSearches'),
					wikipediaWrapper: popover.querySelector('.js-wikiSect'),
					wiktionaryWrapper: popover.querySelector('.js-wiktSect'),
				}
			}

			createCustomEvents() {


				popover.querySelectorAll('.js-tab').forEach(tab => tab.addEventListener('click', ev => {
					const tabSelect = new CustomEvent('tabselect', {
						bubbles: true,
						detail: {
							target: ev.currentTarget.attributes.getNamedItem('target').value,
							element: ev.target
						}
					});

					popover.dispatchEvent(tabSelect);
				}));
			}
		}

		return new Popover(popover);



		function setThumbsError() {
			var thumbWrapper = popover.querySelector('.js-wikiSearches');

			removeChildrenFrom(thumbWrapper);
			thumbWrapper.appendChild(document.createTextNode(`Didn't find any info 😕`));

			return popover;
		}

		/**
		 * 
		 * @param {Object} articleObj
		 * @param {String} articleObj.extract
		 * @param {String} articleObj.fullurl
		 * @param {String} articleObj.pagelanguage
		 * @param {Object} articleObj.thumbnail
		 * @param {Number} articleObj.thumbnail.height
		 * @param {String} articleObj.thumbnail.source
		 * @param {Number} articleObj.thumbnail.width
		 */
		function insertArticle(articleObj) {

			var wikiSect = popover.querySelector('.js-wikiSect');
			var content = wikipediaArticle({
				title: articleObj.title,
				text: articleObj.extract,
				image: articleObj.thumbnail,
				url: articleObj.fullurl
			});

			var imageElem = content.querySelector('.js-articleImage');

			showPage('js-wikiSect');
			removeChildrenFrom(wikiSect);

			imageElem.onload = () => {
				let img = imageElem;
				let minHeight = 200;
				let scale = minHeight / img.naturalWidth;

				img.style.height = `${img.naturalHeight * scale}px`;
				img.style.width = `${img.naturalWidth * scale}px`;
				if (img.height < minHeight && content.clientHeight <= minHeight) {
					wikiSect.setAttribute('style', `max-height: ${content.clientHeight}px;`);
					wikiSect.setAttribute('style', `min-height: ${content.clientHeight}px;`);
				} else if (img.height >= 200) {
					wikiSect.setAttribute('style', `min-height: ${img.height}px;`);
					wikiSect.setAttribute('style', `max-height: ${img.height}px;`);
				}
			};
			wikiSect.appendChild(content);

			return popover;
		}

		function insertBlankData({ area = '' }) {

			var wikiSect = popover.querySelector('.js-wikiSect');
			var thumbWrapper = popover.querySelector('.js-wikiSearches');

			var areaToDisplay = {
				thumbnails: () => {
					removeChildrenFrom(thumbWrapper);
					thumbWrapper.appendChild(blankThumbnails());
				},
				wiktionary: () => {

				},
				article: () => {
					showPage('js-wikiSect');
					const previousArticle = wikiSect.querySelector('.js-wikiArticle');
					if (previousArticle)
						wikiSect.removeChild(previousArticle)

					wikiSect.appendChild(blankArticle());
				}
			};
			try {
				areaToDisplay[area]();
			} catch (error) {

			}
			return popover;
		}

		function insertDictionary(data) {
			var wiktWrapper = popover.querySelector('.js-wiktSect');
			var wiktWrapper = removeChildrenFrom(wiktWrapper);

			if (data) {
				wiktWrapper.appendChild(wiktionaryArticle(data));
				enableTab(2);
			} else {
				disableTab(2);
			}

		}

		/**
		 * Generates the Wiktionary content based on given data.
		 * @param {object} article The data to use as the article.
		 * @returns {DocumentFragment} The dictionary section to be inserted on the popover.
		 */
		function wiktionaryArticle(article) {

			var section = document.createDocumentFragment();

			Object.entries(article).forEach(entrie => { //foreach language
				try {
					var partsOfSpeech = entrie[1]
					var language = entrie[1][0].language;

					const span = newElement('span', `s${uniqueId()}`, ['dict-lang'])
					const ul = newElement('ul', '', ['dict-lang--sections']);

					partsOfSpeech.forEach(group => {

						const liPoS = document.createRange().createContextualFragment(`
                    	<li id="\`li${uniqueId()}\`">
                    	    <span class="dict-partofspeach">${group.partOfSpeech}</span>
                    	    <ol type="1" id="dictDefs" class="dict-definition">
                    	    </ol>
                    	</li>`);


						group.definitions.forEach(def => {
							const wordDefinition = newElement('li');
							wordDefinition.innerText = def.definition.replace(/(<script(\s|\S)*?<\/script>)|(<style(\s|\S)*?<\/style>)|(<!--(\s|\S)*?-->)|(<\/?(\s|\S)*?>)/g, '');
							liPoS.querySelector('#dictDefs').appendChild(wordDefinition);
						});

						span.innerText = language;
						ul.appendChild(liPoS);
						section.appendChild(span);
						section.appendChild(ul);


					});
				} catch (error) {
					disableTab(2);
				}
			});

			return section;
		}

		/**
		 * Generates the Wikipedia content based on given data.
		 * @param {string} text The article's text.
		 * @returns {object} text The article's image data (source).
		 */
		function wikipediaArticle({ title, text, image, url }) {
			var section = document.createDocumentFragment();
			var originalWord = (() => {
				let loweredText = text.toLowerCase();
				let loweredTitle = title.toLowerCase();
				let startIndex = loweredText.search(loweredTitle);
				let endIndex = startIndex + title.length;
				return text.substring(startIndex, endIndex)
			})();
			var formatedText = text.replace(originalWord, `<strong><a href="${url}" target="_blank" rel="noopener noreferrer" title="View on Wikipedia">${originalWord}</a></strong>`)
			let frag = `
                <div id="wikiArticle" class="js-wikiArticle">
                    <img id="popoverImage" class="popoverImage js-articleImage" src="${image.source || 'https://raw.githubusercontent.com/g-nogueira/WikiLink/master/public/images/404/01image404--200.png'}">
                    <p class="js-wikiInfo popoverText">${formatedText}</p>
                </div>
                `;

			return section.appendChild(document.createRange().createContextualFragment(frag).firstElementChild);
		}

		/**
		 * Generates a blank Wikipedia's article.
		 * @param {number} paragraphsCount The number of paragraphs.
		 */
		function blankArticle(paragraphsCount = 8) {
			var section = document.createDocumentFragment();
			var paragraphs = "";


			for (let p = 0; p < paragraphsCount; p++) {
				paragraphs = paragraphs.concat('<div class="description--blank"></div>');
			}

			let frag = `
                <div id="wikiArticle" class="js-wikiArticle wikiArticle--blank">
                    <div id="popoverImage" class="popoverImage--blank"></div>
					<section class="text--blank">${paragraphs}</section>
                </>
                `;

			return section.appendChild(document.createRange().createContextualFragment(frag).firstElementChild);
		}

		/**
		 * Converts a raw object list to Wikipedia's thumbails.
		 * @param {object} thumbList The data returned from the wiktionary.
		 * @returns {DocumentFragment} The list of thumbnails.
		 */
		function thumbnailsToHtml(thumbList) {

			var section = document.createDocumentFragment();

			thumbList
				.map(thumbnailToHtml)
				.forEach(thumbnail => section.appendChild(thumbnail));

			return section;
		}

		function thumbnailToHtml(rawTag) {
			try {
				var thumbnail = `
                <div id="${rawTag.pageid}" lang="${rawTag.lang}" class="js-item item">
                    <section class="image">
                        <img src="${rawTag.thumbnail.source || "https://raw.githubusercontent.com/g-nogueira/WikiLink/master/public/images/404/01image404--70.png"}" alt="">
                    </section>
                    <section class="info">
                        <div class="js-title title">${rawTag.title}</div>
                        <div class="description">${rawTag.terms.description[0]}</div>
                    </section>
				</div>`;
			} catch (error) {
				var thumbnail = `<div></div>`;
			}
			return newFragment(thumbnail).firstElementChild;
		}

		function blankThumbnails(quantity = 6) {

			var section = document.createDocumentFragment();

			for (let i = 0; i < quantity; i++) {
				let frag = `
                <div class="js-item item item--blank">
                    <section class="image--blank"></section>
                    <section class="info">
                        <div class="js-title title--blank"></div>
                        <div class="description--blank"></div>
                        <div class="description--blank"></div>
                    </section>
                </div>`;

				section.appendChild(document.createRange().createContextualFragment(frag).firstElementChild);
			}

			return section;
		}

		/**
		 * Displays the popover based on given selection, cal1 and cal2 coordinates.
		 * @param {Selection} selection The current window selection on DOM.
		 * @param {*} cal1 
		 * @param {*} cal2 
		 */
		function appendPopover(selection, cal1, cal2) {
			/**From:
			 * https://stackoverflow.com/questions/39283159/how-to-keep-selection-but-also-press-button
			 */
			var selRange = selection.getRangeAt(0).getBoundingClientRect();
			var rb1 = DOMRect(cal1);
			var rb2 = DOMRect(cal2);

			popover.style.top = `${(selRange.bottom - rb2.top) * 100 / (rb1.top - rb2.top)}px`;
			let leftPosition = calcLeftPos(selRange, rb1, rb2);

			if (leftPosition + popover.clientWidth > window.innerWidth) {
				// popover.attributeStyleMap.set('left', CSS.px(leftPosition) - popover.clientWidth + selRange.width);
				popover.style.left = `${calcLeftPos(selRange, rb1, rb2) - popover.clientWidth + selRange.width}px`
			} else {
				// popover.attributeStyleMap.set('left', CSS.px((selRange.left - rb2.left) * 100 / (rb1.left - rb2.left)));
				popover.style.left = `${(selRange.left - rb2.left) * 100 / (rb1.left - rb2.left)}px`;
			}

			popover.classList.add('popover--enabled');

			function DOMRect(element) {
				const r = document.createRange()
				r.selectNode(element)
				return r.getBoundingClientRect();
			}

			function calcLeftPos(selRange, rb1, rb2) {
				return (selRange.left - rb2.left) * 100 / (rb1.left - rb2.left);
			}


		}

		function removeChildrenFrom(element) {
			while (element.hasChildNodes()) {
				element.removeChild(element.lastChild);
			}

			return element;
		}

		function isPopoverChild(elemIdentifier = '') {
			try {
				return popover.querySelector(elemIdentifier) === null ? false : true;
			} catch (error) {
				return false;
			}
		}

		/**
		 * @param {number} delay The delay in milliseconds to hide the popover.
		 */
		function hidePopover(delay = 300) {
			setTimeout(() => {
				popover.classList.remove('popover--enabled');
				const hideEvent = new CustomEvent('popoverHidden', {
					bubbles: true,
					detail: {
						element: popover,
					}
				});

				popover.dispatchEvent(hideEvent);
			}, delay);
		}

		function uniqueId() {
			return (new Date()).getTime();
		}

		/**
		 * Disables a tab by given id.
		 * @param {number} tabId  The id of the tab to be disabled (1: Wikipedia | 2: Wiktionary).
		 */
		function disableTab(tabId) {
			var tabs = {
				1: '.js-wikiTab',
				2: '.js-wiktTab'
			}
			popover.querySelector(tabs[tabId]).setAttribute('disabled', 'disabled');
		}

		/**
		 * Enables a tab by given id.
		 * @param {number} tabId  The id of the tab to be enabled (1: Wikipedia | 2: Wiktionary).
		 */
		function enableTab(tabId) {
			var tabs = {
				1: '.js-wikiTab',
				2: '.js-wiktTab'
			}
			if (popover.querySelector(tabs[tabId]).hasAttribute('disabled')) {
				popover.querySelector(tabs[tabId]).removeAttribute('disabled');
			}
		}

		function newFragment(codeString = '<div></div>') {
			return document.createRange().createContextualFragment(codeString);
		}

		function isDisabled(element) {
			return element.hasAttribute('disabled');
		}

		function hideElements(identifier = '') {

			if (identifier instanceof HTMLElement) {

				identifier.classList.add('hidden');

			} else if (identifier instanceof NodeList) {

				identifier.forEach(el => el.classList.add('hidden'));

			} else if (Array.isArray(identifier)) {

				identifier.forEach(el => {
					popover.querySelectorAll(el).forEach(el => el.classList.add('hidden'));
				});

			} else if (typeof identifier === "string") {

				popover.querySelectorAll(identifier).forEach(el => el.classList.add('hidden'));
			}
		}

		function showElements(identifier = '') {
			if (identifier instanceof HTMLElement) {

				identifier.classList.remove('hidden');

			} else if (identifier instanceof NodeList) {

				identifier.forEach(el => el.classList.remove('hidden'));

			} else if (Array.isArray(identifier)) {

				identifier.forEach(el => {
					popover.querySelectorAll(el).forEach(el => el.classList.remove('hidden'));
				});

			} else if (typeof identifier === "string") {

				popover.querySelectorAll(identifier).forEach(el => el.classList.remove('hidden'));
			}


		}

		function newElement(element = 'div', id = '', classList = []) {
			var el = document.createElement(element);
			el.id = id || el.id;
			if (classList.length) {
				el.classList.add(classList);
			}

			return el;
		}

		function showPage(pageClass, condition = true) {
			if (condition) {
				var className = pageClass.match(/([^.].+)/g)[0];
				var previousPage;
				popover.querySelectorAll('.js-infoSect').forEach(section => {
					if (!section.classList.contains('hidden'))
						previousPage = section;
					if (!section.classList.contains(className)) {
						hideElements(section);
					} else {
						section.classList.remove('hidden');
						const changePageEvent = new CustomEvent('pagechange', {
							bubbles: true,
							detail: {
								className: className,
								element: section,
								previous: previousPage
							}
						});

						popover.dispatchEvent(changePageEvent);
					}
				});
			}
		}
	}
})();
},{}],5:[function(require,module,exports){
/*
#### DOM manipulation, data input and output ####
@------------------------------------------------@
| It creates a div element at the displayed page |
| DOM, as well as two "cals", for padding sakes. |
| Gets the ranges of these elements and listen to|
| the onmouseup event, that gets the selected    |
| text, parses it and request data to the API.   |
| The response will be displayed into a popover. |
@------------------------------------------------@
*/

(async function () {
	"use strict";

	const popoverDB = require("../utils/Storage");
	const wikiAPI = require("../contentScripts/WikipediaAPI");
	const wiktAPI = require("../contentScripts/WiktionaryAPI");
	const popoverManager = require("../models/popoverManager");
	const popoverDesigner = require("../models/popoverDesigner");

	var element = popoverDesigner.getBasicShell();
	var popover = popoverManager(element);
	var wikipediaAPI = wikiAPI;
	var wiktionaryAPI = wiktAPI;
	var isPopoverEnabled = await popoverDB.retrieve('isEnabled');
	var selectedString = '';

	initDOMEvents();


	////////////////// IMPLEMENTATION //////////////////

	function initDOMEvents() {
		popover.addEventListener('thumbclick', ev => loadArticle(ev.detail.article.lang, ev.detail.article.id))
		popover.addEventListener('tabselect', ev => loadWictionary(selectedString));

		startProcess();
	}

	function startProcess() {
		var urlParams = new URLSearchParams(window.location.search);
		var title = urlParams.get('title');

		if (isPopoverEnabled && title) {

			popover.showPage('js-wikiSearches');
			selectedString = title;
			wikipediaAPI.getPageList({ term: title, range: title }).then(popover.setThumbnails);
			wiktionaryAPI.getDefinitions(title).then(popover.setDictionary);

			popover.isLoading({ area: 'thumbnails' });
		}
	}

	function loadArticle(language, pageId) {
		popover.isLoading({ area: 'article' });

		wikipediaAPI.getPageById({ pageId: pageId, imageSize: 250, language }).then(async article => {
			popover.setArticle(article);
			loadWictionary(article.title);
		});
	}

	function loadWictionary(title) {
		wiktionaryAPI
			.getDefinitions(title)
			.then(resp => popover.setDictionary(resp))
	}

}());
},{"../contentScripts/WikipediaAPI":1,"../contentScripts/WiktionaryAPI":2,"../models/popoverDesigner":3,"../models/popoverManager":4,"../utils/Storage":6}],6:[function(require,module,exports){
"use strict";


/**
 * Manages and facilitate storage (chrome.storage.sync) requests and watchers.
 */
module.exports = new (class Storage {

	constructor() {
		this._errorCode = {
			1: key => `Object "${key}" not found`,
			2: (key, property) => `Object property "${key}.${property}" not found in storage.`,
			3: property => `Object property ".${property}" not found in storage.`
		};

		this._encodeProp = propertyName => {

			let props = {
				isEnabled: 5,
				fallbackLang: 1,
				nlpLangs: 4,
				shortcut: 3,
				popupMode: 2
			}

			return props[propertyName];
		}

		this._decodeProp = propertyName => {

			let props = {
				5: 'isEnabled',
				1: 'fallbackLang',
				4: 'nlpLangs',
				3: 'shortcut',
				2: 'popupMode'
			}

			return props[propertyName];
		}

		this._decodeObj = obj => {
			let decodedObj = {};
			Object.keys(obj).forEach(key => {
				decodedObj[this._decodeProp(key)] = obj[key];
			});

			return decodedObj;
		}

	}

	update(property, value) {
		return new Promise(async (resolve, reject) => {
			var dataString = '';
			var data = await this.retrieve();

			data[this._encodeProp(property)] = value;
			dataString = JSON.stringify(data);

			chrome.storage.sync.set({
				wldt: dataString
			}, () => resolve(true));
		});
	}

	retrieve(property = '') {
		var errorCount = 0;
		return new Promise(async (resolve, reject) => {
			var dataString = '';
			try {
				dataString = await new Promise(resolve => chrome.storage.sync.get('wldt', obj => resolve(obj['wldt'])));
				var data = JSON.parse(dataString);

				if (property.length > 0)
					resolve(data[this._encodeProp(property)])
				else resolve(data);

			} catch (error) {
				errorCount += 1;
				if (errorCount >= 2) {
					reject(error);
				} else {
					let wikilinkData = JSON.stringify({
						1: 'en',
						2: 'shortcut',
						3: ['ShiftLeft', 'AltLeft'],
						4: ['por', 'eng', 'esp', 'rus'],
						5: true
					});
					chrome.storage.sync.set({ wldt: wikilinkData }, () => this.retrieve(property));
				}
			}

		});
	}


	/**
	 * Listens to storage changes in given object and executes a function in a onChanged event.
	 * @param {*} objName The name of the object in the storage to listens.
	 * @returns {object} A function to pass as an argument the function to execute on event.
	 */
	onChanges(fn) {

		var decodedObj = this._decodeObj;

		chrome.storage.onChanged.addListener((changes, areaName) => {
			//Popover enabled state changed
			if (changes['wldt']) {
				fn(decodedObj(JSON.parse(changes['wldt'].oldValue)), decodedObj(JSON.parse(changes['wldt'].newValue)));
			};
		});
	}
});
},{}]},{},[5]);
