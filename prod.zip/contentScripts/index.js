(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

/**
 * A popover DOM management API
 * The Popover element used in the manager dispatches some events:
 * - "shortcutMatch" - When the user clicks on a tab (List, Wikipedia, or Wiktionary),
 */
module.exports = class Popover {
    constructor() {
        this.iframeUrl = "";
        this.iframe = {};
        this.shadowMode = "open";

        this.addEventListener = (eventName, eventListener) => this.iframe.addEventListener(eventName, eventListener);
    }

    /**
     * Initialize DOM preferences
     *
     * @param {Object} options
     * @param {String} options.iframeUrl
     * @param {Number} options.iframeWidth
     * @param {Number} options.iframeHeight
     * @param {"open"|"closed"} options.shadowMode A string specifying the encapsulation mode for the shadow DOM tree
     * @returns
     */
    init(options) {
        this.iframeUrl = options.iframeUrl;
        this.iframeWidth = options.iframeWidth || 501;
        this.iframeHeight = options.iframeHeight || 276;
        this.shadowMode = options.shadowMode;

        return this;
    }

    /**
     * Insert an iframe into the DOM using the options specified on `init()` method.
     *
     */
    insertIframe() {
        let parentElement = document.createElement("div");
        let shadow = parentElement.attachShadow({ mode: this.shadowMode });
        let iframeNode = document.createElement("iframe");

        parentElement.classList.add("js-wikilink");
        parentElement.style = `
                position: absolute;
                background: transparent;
            `;

        iframeNode.style = `
                width: ${this.iframeWidth}px;
                height: ${this.iframeHeight}px;
                border: none;
                z-index: 2139999998;
                box-shadow: 0 30px 90px -20px rgba(0, 0, 0, 0.3), 0 0 1px #a2a9b1;
            `;

        shadow.appendChild(iframeNode);
        document.body.appendChild(parentElement);

        let iframeElement = shadow.querySelector("iframe");
        iframeElement.parent = parentElement;

        this.iframe = iframeElement;
    }

    /**
     * Display the iframe on the specified x,y coordinates.
     * 
     * @param {String} title
     * @param {Object} position
     * @param {Number} position.top
     * @param {Number} position.left
     * @param {Object} [options={}]
     * @param {Number} options.width
     * @param {Number} options.height
     */
    show(title, position, options = {}) {
        this.iframe.parent.style.top = position.top + "px";
        this.iframe.parent.style.left = position.left + "px";

        this.iframe.style.width = options.width || this.iframe.style.width;
        this.iframe.style.height = options.height || this.iframe.style.height;

        this.iframe.src = this.iframeUrl + "?title=" + title;

        this.iframe.classList.add("popover--enabled");
    }

    /**
     * Hide the iframe
     *
     * @param {*} options
     * @param {Number} [delay=300] A delay in milliseconds to hide the iframe.
     */
    hide(options, delay = 300) {
        setTimeout(() => {
            this.iframe.classList.remove("popover--enabled");
            const hideEvent = new CustomEvent("popoverHidden", {
                bubbles: true,
                detail: {
                    element: this.iframe,
                }
            });

            this.iframe.dispatchEvent(hideEvent);
        }, delay);
    }

};
},{}],2:[function(require,module,exports){
/*
#### DOM manipulation, data input and output ####
@------------------------------------------------@
| It creates a div element at the displayed page |
| DOM, as well as two "cals", for padding sakes. |
| Gets the ranges of these elements and listen to|
| the onmouseup event, that gets the selected    |
| text, parses it and request data to the API.   |
| The response will be displayed into a popover. |
@------------------------------------------------@
*/

(async function () {
	"use strict";

	const storageHelper = require("../utils/Storage");
	const shortcutHelper = require("../utils/Shortcut");
	const selectionHelper = require("../utils/Selection");
	const PopoverHelper = require("./Popover");


	let popoverInstance = new PopoverHelper();
	let userSettings = {
		isPopoverEnabled: await storageHelper.retrieve('isEnabled'),
		shortcut: await storageHelper.retrieve('shortcut')
	};


	/**
	 * Initialize an iframe element and insert it into the DOM
	 *
	 */
	function initializeIframe() {
		popoverInstance.init({
			iframeUrl: chrome.extension.getURL('pages/popoverGUI.html'),
			iframeWidth: 501,
			iframeHeight: 276,
			shadowMode: "open"
		});
		popoverInstance.insertIframe();
	}

	/**
	 *
	 *
	 */
	function listenEvents() {
		// Listen for the shortcut to be triggered
		shortcutHelper.init(userSettings.shortcut);
		shortcutHelper.addEventListener("shortcutMatch", (ev) => {
			let selectionObj = selectionHelper.getSelection();
			let selectionString = selectionObj.toString();
			let iframePosition = selectionHelper.getOffsetBottomCoordinates(selectionObj);

			if (userSettings.isPopoverEnabled && !selectionString.isCollapsed && !isEmptySelection(selectionString)) {
				popoverInstance.show(selectionString, iframePosition);
			}
		});

		storageHelper.onChanges((oldV, newV) => {
			shortcut = newV.shortcut;
			userSettings.isPopoverEnabled = newV.isEnabled;
			popoverInstance.shortcut = shortcut;
		});
	}

	function isEmptySelection(selection) {
		//If given argument is not empty neither is white spaces
		return !(selection && /\S/.test(selection));
	}


	initializeIframe();
	listenEvents();
}());
},{"../utils/Selection":4,"../utils/Shortcut":5,"../utils/Storage":6,"./Popover":1}],3:[function(require,module,exports){
"use strict";

module.exports = class Events {

    /**
     * Creates an instance of Events.
     * @param {Object} [options={}]
     * @param {HTMLElement} [options.dispatcher]
     * @param {Object} options.events
     * 
     */
    constructor(options = {}) {
        this._dispatcher = options.dispatcher || document.createElement("div");
        this.events = options.events;


        this.shortcut = [];
    }

    /**
     * Dispatches a synthetic event to target and returns true if either event's cancelable attribute value is false or its preventDefault() method was not invoked, and false otherwise.
     *
     * @param {String} type
     * @param {Any} details Any custom data to be dispatch with the event.
     * @param {Boolean} canBubble A boolean indicating whether the event goes through its target's ancestors in reverse tree order.
     * @param {Boolean} cancelable A boolean indicating whether the event can be canceled by invoking the preventDefault() method.
     */
    dispatchEvent(type, details, canBubble = true, cancelable = true) {

        const event = new CustomEvent(type, {
            bubbles: canBubble,
            cancelable: cancelable,
            detail: details,
        })


        return this._dispatcher.dispatchEvent(event);
    }

    /**
     * Appends an event listener for events whose type attribute value is `type`. The callback argument sets the callback that will be invoked when the event is dispatched.
     *
     * @param {String} type
     * @param {(this: HTMLElement, ev: HTMLElementEventMap[K]) => any} eventListener
     * @return
     */
    addEventListener(type, eventListener) {
        this._dispatcher.addEventListener(type, eventListener);
    }

    get _shortcutMatchEvent() {
        return new CustomEvent("shortcutMatch", {
            bubbles: true,
            detail: {}
        });
    }

};
},{}],4:[function(require,module,exports){
(() => {
	"use strict";

	module.exports = new (class SelectionHelper {

		constructor() {
			this.selection = {};
		}

		/**
		 * Get the current selection.
		 *
		 * @returns {Selection}
		 */
		getSelection() {
			return window.getSelection();
		}

		/**
		 * Get the ClientRect of a selection.
		 *
		 * @param {Selection} selection
		 * @returns {DOMRect}
		 */
		getSelectionPosition(selection) {

			var range = selection.getRangeAt(0);
			var DOMRect = range.getBoundingClientRect();

			return DOMRect;
		}

		/**
		 * Get a ClientRect from the bottom left corner of a selection.
		 *
		 * @param {Selection} selection
		 * @returns {DOMRect}
		 */
		getOffsetBottomCoordinates(selection) {
			var temporaryNode = this._createUniqueNode();
			var temporaryNodeTop = 0;
			var range = selection.getRangeAt(0);
			var clientRect = range.getBoundingClientRect();

			// Insert a node at the start of the selection and get its position relative to the top of the body
			range.insertNode(temporaryNode);
			temporaryNodeTop = temporaryNode.offsetTop;

			// Determine the position below the selection as scrolledHeight (i.e.: temporaryNodeTop) + selectionHeight
			var position = new DOMRect(clientRect.x, clientRect.height + temporaryNodeTop, clientRect.width, clientRect.height);

			// Remove the previously inserted node
			temporaryNode.parentElement.removeChild(temporaryNode);

			return position;
		}


		_createUniqueNode() {
			var node = document.createElement("span");

			node.id = (new Date()).getTime();
			node.style.position = "absolute";

			return node;
		}

	});

})();
},{}],5:[function(require,module,exports){
"use strict";
const Events = require("./Events");
module.exports = new (class ShortcutHelper extends Events {

	constructor() {
		super();

		this.shortcut = [];
		this.events = {
			/** The `shortcutMatch` event is fired when a matching shortcut is pressed. */
			shortcutMatch: "shortcutMatch"
		};

	}

	/**
	 *
	 *
	 * @param {Array<String>} shortcut An array of key names
	 */
	init(shortcut) {
		this.shortcut = shortcut;

		var timeOutId = null;
		var keyGroup = [];
		var that = this;

		document.addEventListener("keydown", function onKeyDown(ev) {

			clearTimeout(timeOutId);

			if (keyGroup.toString() === shortcut.toString()) {

				that.dispatchEvent(that.events.shortcutMatch, { shortcut: shortcut });
				keyGroup = [];

			} else if (keyGroup.length < shortcut.length && !keyGroup.includes(ev.code)) {
				keyGroup.push(ev.code);
				onKeyDown(ev);
			}

			timeOutId = setTimeout(() => keyGroup = [], 10 * 1000);
		});

		document.addEventListener("keyup", function onKeyUp(ev) {
			var index = keyGroup.indexOf(ev.code);
			if (index !== -1) {
				keyGroup.splice(index, 1);
			}
		});
	}

});
},{"./Events":3}],6:[function(require,module,exports){
"use strict";


/**
 * Manages and facilitate storage (chrome.storage.sync) requests and watchers.
 */
module.exports = new (class StorageHelper {

	constructor() {
		this._errorCode = {
			1: (key) => `Object "${key}" not found`,
			2: (key, property) => `Object property "${key}.${property}" not found in storage.`,
			3: (property) => `Object property ".${property}" not found in storage.`
		};

		this._encodeProp = (propertyName) => {

			let props = {
				isEnabled: 5,
				fallbackLang: 1,
				nlpLangs: 4,
				shortcut: 3,
				popupMode: 2
			}

			return props[propertyName];
		};

		this._decodeProp = (propertyName) => {

			let props = {
				5: "isEnabled",
				1: "fallbackLang",
				4: "nlpLangs",
				3: "shortcut",
				2: "popupMode"
			}

			return props[propertyName];
		};

		this._decodeObj = (obj) => {
			let decodedObj = {};
			Object.keys(obj).forEach(key => {
				decodedObj[this._decodeProp(key)] = obj[key];
			});

			return decodedObj;
		};

	}

	update(property, value) {
		return new Promise(async (resolve, reject) => {
			var dataString = "";
			var data = await this.retrieve();

			data[this._encodeProp(property)] = value;
			dataString = JSON.stringify(data);

			chrome.storage.sync.set({
				wldt: dataString
			}, () => resolve(true));
		});
	}

	retrieve(property = "") {
		var errorCount = 0;
		return new Promise(async (resolve, reject) => {
			var dataString = "";
			try {
				dataString = await new Promise(resolve => chrome.storage.sync.get("wldt", obj => resolve(obj["wldt"])));
				var data = JSON.parse(dataString);

				if (property.length > 0)
					resolve(data[this._encodeProp(property)])
				else resolve(data);

			} catch (error) {
				errorCount += 1;
				if (errorCount >= 2) {
					reject(error);
				} else {
					let wikilinkData = JSON.stringify({
						1: "en",
						2: "shortcut",
						3: ["ShiftLeft", "AltLeft"],
						4: ["por", "eng", "esp", "rus"],
						5: true
					});
					chrome.storage.sync.set({ wldt: wikilinkData }, () => this.retrieve(property));
				}
			}

		});
	}


	/**
	 * Listens to storage changes in given object and executes a function in a onChanged event.
	 * @param {*} objName The name of the object in the storage to listens.
	 * @returns {object} A function to pass as an argument the function to execute on event.
	 */
	onChanges(fn) {

		var decodedObj = this._decodeObj;

		chrome.storage.onChanged.addListener((changes, areaName) => {
			//Popover enabled state changed
			if (changes["wldt"]) {
				fn(decodedObj(JSON.parse(changes["wldt"].oldValue)), decodedObj(JSON.parse(changes["wldt"].newValue)));
			}
		});
	}
});
},{}]},{},[2]);
