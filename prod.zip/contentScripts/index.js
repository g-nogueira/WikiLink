(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
(() => {
    'use strict';

    /**
     * A popover DOM management API
     * The Popover element used in the manager dispatches some events:
     * - "tabselect" - When the user clicks on a tab (List, Wikipedia, or Wiktionary),
     * - "popoverHidden" - When the popover has finished the hidden process,
     * - "thumbclick" - When the user selects an article of the search response list,
     * - "pagechange" - When a change of page occurs, independent of the trigger,
     */
    module.exports = class iframeUtils {
        constructor() {
            this.iframe = this.init();
            this.render = this.show;
            this.isChild = this.isPopoverChild;

            this.addEventListener = (eventName, eventListener) => this.iframe.addEventListener(eventName, eventListener);

        }

        init() {
            let div = document.createElement('div');
            let shadow = div.attachShadow({ mode: 'open' });
            let iframeNode = document.createElement("iframe");

            div.classList.add('js-wikilink');
            div.style = `
                position: absolute;
                background: transparent;
            `;

            iframeNode.style = `
                width: 600px;
                height: 350px;
                border: none;
                z-index: 2139999998;
            `;

            shadow.appendChild(iframeNode);
            document.body.appendChild(div);
            let iframeElement = shadow.querySelector('iframe');
            iframeElement.parent = div;

            return iframeElement;
        }

        /**
         *
         *
         * @param {Selection} selection
         * @returns
         */
        getPosition(selection) {

            var temporaryNode = this.createUniqueNode();
            var temporaryNodeTop = 0;
            var range = selection.getRangeAt(0);
            var clientRect = range.getBoundingClientRect();
            var position = { top: 0, left: 0 };

            // Insert a node at the start of the selection and get its position relative to the top of the body
            range.insertNode(temporaryNode);
            temporaryNodeTop = temporaryNode.offsetTop;

            // Determine the position below the selection as scrolledHeight (i.e.: temporaryNodeTop) + selectionHeight
            position.top = temporaryNodeTop + clientRect.height + "px";
            position.left = clientRect.left + "px";

            // Remove the previously inserted node
            temporaryNode.parentElement.removeChild(temporaryNode);

            this.iframe.classList.add('popover--enabled');

            return position;
        }

        /**
         * Displays the popover based on given selection, cal1 and cal2 coordinates.
         * @param {Selection} selection The current window selection on DOM.
         */
        show(title, selection) {
            let pos = this.getPosition(selection);

            this.iframe.parent.style.top = pos.top;
            this.iframe.parent.style.left = pos.left;
            this.iframe.src = chrome.extension.getURL('pages/popoverGUI.html') + "?title=" + title;
        }

        isPopoverChild(elemIdentifier = '') {
            try {
                return iframe.querySelector(elemIdentifier) === null ? false : true;
            } catch (error) {
                return false;
            }
        }

        /**
         * @param {number} delay The delay in milliseconds to hide the popover.
         */
        hide(options, delay = 300) {
            setTimeout(() => {
                this.iframe.classList.remove('popover--enabled');
                const hideEvent = new CustomEvent('popoverHidden', {
                    bubbles: true,
                    detail: {
                        element: this.iframe,
                    }
                });

                this.iframe.dispatchEvent(hideEvent);
            }, delay);
        }

        createUniqueNode() {
            var node = document.createElement("span");

            node.id = this.uniqueId;
            node.style.position = "absolute";

            return node;
        }

        get uniqueId() {
            return (new Date()).getTime();
        }

    }
})();
},{}],2:[function(require,module,exports){
/*
#### DOM manipulation, data input and output ####
@------------------------------------------------@
| It creates a div element at the displayed page |
| DOM, as well as two "cals", for padding sakes. |
| Gets the ranges of these elements and listen to|
| the onmouseup event, that gets the selected    |
| text, parses it and request data to the API.   |
| The response will be displayed into a popover. |
@------------------------------------------------@
*/

(async function () {
	"use strict";

	const popoverDB = require("../utils/StorageManager");
	const iframeUtils = require("./iframe");

	var popover = new iframeUtils();
	var isPopoverEnabled = await popoverDB.retrieve('isEnabled');
	var shortcut = await popoverDB.retrieve('shortcut');
	var popupMode = await popoverDB.retrieve('popupMode');
	var keyGroup = [];

	initDOMEvents();


	////////////////// IMPLEMENTATION //////////////////

	function initDOMEvents() {
		var wikilink = document.body.querySelector('.js-wikilink');
		var timeOutId = null;

		popoverDB.onChanges((oldV, newV) => {
			shortcut = newV.shortcut;
			popupMode = newV.popupMode;
			isPopoverEnabled = newV.isEnabled;

			changePopupMode(newV.popupMode);
		});

		changePopupMode(popupMode);

		wikilink.addEventListener('mouseleave', onMouseLeave);

		function changePopupMode(popupMode) {
			if (popupMode === 'shortcut') {
				document.removeEventListener('mouseup', onMouseUp);
				document.addEventListener('keydown', onKeyDown)
				document.addEventListener('keyup', onKeyUp)
			} else if (popupMode === 'default') {
				document.addEventListener('mouseup', onMouseUp);
				document.removeEventListener('keydown', onKeyDown)
				document.removeEventListener('keyup', onKeyUp)
			}
		}

		function onMouseLeave(ev) {
			popover.hide();
		}

		function onKeyDown(ev) {

			clearTimeout(timeOutId);

			if (keyGroup.toString() === shortcut.toString()) {
				startProcess();
				keyGroup = [];
			} else if (keyGroup.length < shortcut.length && !keyGroup.includes(ev.code)) {
				keyGroup.push(ev.code);
				onKeyDown(ev);
			}
			// console.table(keyGroup);

			timeOutId = setTimeout(() => keyGroup = [], 10 * 1000);
		}

		function onKeyUp(ev) {
			var index = keyGroup.indexOf(ev.code);
			if (index !== -1) {
				keyGroup.splice(index, 1);
			}
		}

		function onMouseUp(ev) {
			if (ev.which === 1 && !popover.isChild(`#${ev.target.id}`)) {
				startProcess();
			}
		}

	}

	function startProcess() {
		var selectionObj = window.getSelection();
		var selectionString = selectionObj.toString();

		if (isPopoverEnabled && !selectionString.isCollapsed && !isEmptySelection(selectionString)) {

			popover.show(selectionString, selectionObj);
		}
	}

	function isEmptySelection(selection) {
		//If given argument is not empty neither is white spaces
		return !(selection && /\S/.test(selection));
	}
}());
},{"../utils/StorageManager":3,"./iframe":1}],3:[function(require,module,exports){
(() => {
	'use strict';


	/**
	 * Manages and facilitate storage (chrome.storage.sync) requests and watchers.
	 */
	class PopoverDB {

		constructor() {
			this._errorCode = {
				1: key => `Object "${key}" not found`,
				2: (key, property) => `Object property "${key}.${property}" not found in storage.`,
				3: property => `Object property ".${property}" not found in storage.`
			};

			this._encodeProp = propertyName => {

				let props = {
					isEnabled: 5,
					fallbackLang: 1,
					nlpLangs: 4,
					shortcut: 3,
					popupMode: 2
				}

				return props[propertyName];
			}

			this._decodeProp = propertyName => {

				let props = {
					5: 'isEnabled',
					1: 'fallbackLang',
					4: 'nlpLangs',
					3: 'shortcut',
					2: 'popupMode'
				}

				return props[propertyName];
			}

			this._decodeObj = obj => {
				let decodedObj = {};
				Object.keys(obj).forEach(key => {
					decodedObj[this._decodeProp(key)] = obj[key];
				});

				return decodedObj;
			}

		}

		update(property, value) {
			return new Promise(async (resolve, reject) => {
				var dataString = '';
				var data = await this.retrieve();

				data[this._encodeProp(property)] = value;
				dataString = JSON.stringify(data);

				chrome.storage.sync.set({
					wldt: dataString
				}, () => resolve(true));
			});
		}

		retrieve(property = '') {
			var errorCount = 0;
			return new Promise(async (resolve, reject) => {
				var dataString = '';
				try {
					dataString = await new Promise(resolve => chrome.storage.sync.get('wldt', obj => resolve(obj['wldt'])));
					var data = JSON.parse(dataString);

					if (property.length > 0)
						resolve(data[this._encodeProp(property)])
					else resolve(data);

				} catch (error) {
					errorCount += 1;
					if (errorCount >= 2) {
						reject(error);
					} else {
						let wikilinkData = JSON.stringify({
							1: 'en',
							2: 'shortcut',
							3: ['ShiftLeft', 'AltLeft'],
							4: ['por', 'eng', 'esp', 'rus'],
							5: true
						});
						chrome.storage.sync.set({ wldt: wikilinkData }, () => this.retrieve(property));
					}
				}

			});
		}


		/**
		 * Listens to storage changes in given object and executes a function in a onChanged event.
		 * @param {*} objName The name of the object in the storage to listens.
		 * @returns {object} A function to pass as an argument the function to execute on event.
		 */
		onChanges(fn) {

			var decodedObj = this._decodeObj;

			chrome.storage.onChanged.addListener((changes, areaName) => {
				//Popover enabled state changed
				if (changes['wldt']) {
					fn(decodedObj(JSON.parse(changes['wldt'].oldValue)), decodedObj(JSON.parse(changes['wldt'].newValue)));
				};
			});
		}
	}

	module.exports = new PopoverDB();

})();
},{}]},{},[2]);
