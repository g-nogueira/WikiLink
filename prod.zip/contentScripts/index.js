(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

/**
 * A popover DOM management API
 * The Popover element used in the manager dispatches some events:
 * - "shortcutMatch" - When the user clicks on a tab (List, Wikipedia, or Wiktionary),
 */
module.exports = class Popover {
    constructor() {
        this.iframeUrl = "";
        this.iframe = {};
        this.shadowMode = "open";

        this.addEventListener = (eventName, eventListener) => this.iframe.addEventListener(eventName, eventListener);
    }

    init(options) {
        this.iframeUrl = options.iframeUrl;
        this.iframeWidth = options.iframeWidth || 501;
        this.iframeHeight = options.iframeHeight || 276;
        this.shadowMode = options.shadowMode;

        return this;
    }

    insertIframe() {
        let parentElement = document.createElement("div");
        let shadow = parentElement.attachShadow({ mode: this.shadowMode });
        let iframeNode = document.createElement("iframe");

        parentElement.classList.add("js-wikilink");
        parentElement.style = `
                position: absolute;
                background: transparent;
            `;

        iframeNode.style = `
                width: ${this.iframeWidth}px;
                height: ${this.iframeHeight}px;
                border: none;
                z-index: 2139999998;
                box-shadow: 0 30px 90px -20px rgba(0, 0, 0, 0.3), 0 0 1px #a2a9b1;
            `;

        shadow.appendChild(iframeNode);
        document.body.appendChild(parentElement);

        let iframeElement = shadow.querySelector("iframe");
        iframeElement.parent = parentElement;

        this.iframe = iframeElement;
    }


    /**
     * Displays the popover based on given selection, cal1 and cal2 coordinates.
     * @param {Selection} selection The current window selection on DOM.
     */
    show(title, position) {
        this.iframe.parent.style.top = position.top + "px";
        this.iframe.parent.style.left = position.left + "px";

        this.iframe.style.width = this.iframe.style.width || options.width;
        this.iframe.style.height = this.iframe.style.height || options.height;

        this.iframe.src = this.iframeUrl + "?title=" + title;

        this.iframe.classList.add("popover--enabled");
    }

    /**
     * @param {number} delay The delay in milliseconds to hide the popover.
     */
    hide(options, delay = 300) {
        setTimeout(() => {
            this.iframe.classList.remove("popover--enabled");
            const hideEvent = new CustomEvent("popoverHidden", {
                bubbles: true,
                detail: {
                    element: this.iframe,
                }
            });

            this.iframe.dispatchEvent(hideEvent);
        }, delay);
    }

}
},{}],2:[function(require,module,exports){
/*
#### DOM manipulation, data input and output ####
@------------------------------------------------@
| It creates a div element at the displayed page |
| DOM, as well as two "cals", for padding sakes. |
| Gets the ranges of these elements and listen to|
| the onmouseup event, that gets the selected    |
| text, parses it and request data to the API.   |
| The response will be displayed into a popover. |
@------------------------------------------------@
*/

(async function () {
	"use strict";

	const storageHelper = require("../utils/Storage");
	const shortcutHelper = require("../utils/Shortcut");
	const selectionHelper = require("../utils/Selection");
	const popoverHelper = require("./Popover");

	var isPopoverEnabled = await storageHelper.retrieve('isEnabled');
	var shortcut = await storageHelper.retrieve('shortcut');
	var popoverInstance = new popoverHelper();

	popoverInstance.init({
		iframeUrl: chrome.extension.getURL('pages/popoverGUI.html'),
		iframeWidth: 501,
		iframeHeight: 276,
		shadowMode: "open"
	});
	popoverInstance.insertIframe();

	shortcutHelper.startShortcutListener(shortcut, popoverInstance.iframe);


	popoverInstance.addEventListener("shortcutMatch", () => {
		let selectionObj = selectionHelper.getSelection();
		let selectionString = selectionObj.toString();
		let iframePosition = selectionHelper.getOffsetBottomCoordinates(selectionObj);

		if (isPopoverEnabled && !selectionString.isCollapsed && !isEmptySelection(selectionString)) {

			popoverInstance.show(selectionString, iframePosition);
		}
	});

	storageHelper.onChanges((oldV, newV) => {
		shortcut = newV.shortcut;
		isPopoverEnabled = newV.isEnabled;
		popoverInstance.shortcut = shortcut;
	});



	////////////////// IMPLEMENTATION //////////////////

	function isEmptySelection(selection) {
		//If given argument is not empty neither is white spaces
		return !(selection && /\S/.test(selection));
	}
}());
},{"../utils/Selection":3,"../utils/Shortcut":4,"../utils/Storage":5,"./Popover":1}],3:[function(require,module,exports){
(() => {
	"use strict";

	module.exports = new (class Selection {

		constructor() {
			this.selection = {};
		}

		getSelection() {
			return window.getSelection();
		}

		/**
		 *
		 *
		 * @param {Selection} selection
		 * @returns
		 */
		getSelectionPosition(selection) {

			var temporaryNode = this.createUniqueNode();
			var range = selection.getRangeAt(0);
			var clientRect = range.getBoundingClientRect();
			var position = { top: 0, left: 0 };

			// Determine the position of the selection as selectionHeight
			position.top = clientRect.height;
			position.left = clientRect.left;

			// Remove the previously inserted node
			temporaryNode.parentElement.removeChild(temporaryNode);

			return position;
		}

		getOffsetBottomCoordinates(selection) {
			var temporaryNode = this.createUniqueNode();
			var temporaryNodeTop = 0;
			var range = selection.getRangeAt(0);
			var clientRect = range.getBoundingClientRect();
			var position = { top: 0, left: 0 };

			// Insert a node at the start of the selection and get its position relative to the top of the body
			range.insertNode(temporaryNode);
			temporaryNodeTop = temporaryNode.offsetTop;

			// Determine the position below the selection as scrolledHeight (i.e.: temporaryNodeTop) + selectionHeight
			position.top = temporaryNodeTop + clientRect.height;
			position.left = clientRect.left;

			// Remove the previously inserted node
			temporaryNode.parentElement.removeChild(temporaryNode);

			return position;
		}


		createUniqueNode() {
			var node = document.createElement("span");

			node.id = (new Date()).getTime();
			node.style.position = "absolute";

			return node;
		}

	});

})();
},{}],4:[function(require,module,exports){
"use strict";

module.exports = new (class Selection {

	constructor() {
		this.shortcut = [];
		this.dispatcher = document;

		this.events = {
			shortcutMatchEvent: this.shortcutMatchEvent
		};
	}

	startShortcutListener(shortcut, dispatcher = document) {
		this.shortcut = shortcut;
		this.dispatcher = document;

		var timeOutId = null;
		var keyGroup = [];
		var shortcutMatchEvent = this.events.shortcutMatchEvent;

		document.addEventListener("keydown", onKeyDown);
		document.addEventListener("keyup", onKeyUp);

		function onKeyDown(ev) {

			clearTimeout(timeOutId);

			if (keyGroup.toString() === shortcut.toString()) {

				dispatcher.dispatchEvent(shortcutMatchEvent);
				keyGroup = [];

			} else if (keyGroup.length < shortcut.length && !keyGroup.includes(ev.code)) {
				keyGroup.push(ev.code);
				onKeyDown(ev);
			}

			timeOutId = setTimeout(() => keyGroup = [], 10 * 1000);
		}

		function onKeyUp(ev) {
			var index = keyGroup.indexOf(ev.code);
			if (index !== -1) {
				keyGroup.splice(index, 1);
			}
		}

	}

	get shortcutMatchEvent() {
		return new CustomEvent("shortcutMatch", {
			bubbles: true,
			detail: {}
		});
	}

});
},{}],5:[function(require,module,exports){
"use strict";


/**
 * Manages and facilitate storage (chrome.storage.sync) requests and watchers.
 */
module.exports = new (class Storage {

	constructor() {
		this._errorCode = {
			1: key => `Object "${key}" not found`,
			2: (key, property) => `Object property "${key}.${property}" not found in storage.`,
			3: property => `Object property ".${property}" not found in storage.`
		};

		this._encodeProp = propertyName => {

			let props = {
				isEnabled: 5,
				fallbackLang: 1,
				nlpLangs: 4,
				shortcut: 3,
				popupMode: 2
			}

			return props[propertyName];
		}

		this._decodeProp = propertyName => {

			let props = {
				5: 'isEnabled',
				1: 'fallbackLang',
				4: 'nlpLangs',
				3: 'shortcut',
				2: 'popupMode'
			}

			return props[propertyName];
		}

		this._decodeObj = obj => {
			let decodedObj = {};
			Object.keys(obj).forEach(key => {
				decodedObj[this._decodeProp(key)] = obj[key];
			});

			return decodedObj;
		}

	}

	update(property, value) {
		return new Promise(async (resolve, reject) => {
			var dataString = '';
			var data = await this.retrieve();

			data[this._encodeProp(property)] = value;
			dataString = JSON.stringify(data);

			chrome.storage.sync.set({
				wldt: dataString
			}, () => resolve(true));
		});
	}

	retrieve(property = '') {
		var errorCount = 0;
		return new Promise(async (resolve, reject) => {
			var dataString = '';
			try {
				dataString = await new Promise(resolve => chrome.storage.sync.get('wldt', obj => resolve(obj['wldt'])));
				var data = JSON.parse(dataString);

				if (property.length > 0)
					resolve(data[this._encodeProp(property)])
				else resolve(data);

			} catch (error) {
				errorCount += 1;
				if (errorCount >= 2) {
					reject(error);
				} else {
					let wikilinkData = JSON.stringify({
						1: 'en',
						2: 'shortcut',
						3: ['ShiftLeft', 'AltLeft'],
						4: ['por', 'eng', 'esp', 'rus'],
						5: true
					});
					chrome.storage.sync.set({ wldt: wikilinkData }, () => this.retrieve(property));
				}
			}

		});
	}


	/**
	 * Listens to storage changes in given object and executes a function in a onChanged event.
	 * @param {*} objName The name of the object in the storage to listens.
	 * @returns {object} A function to pass as an argument the function to execute on event.
	 */
	onChanges(fn) {

		var decodedObj = this._decodeObj;

		chrome.storage.onChanged.addListener((changes, areaName) => {
			//Popover enabled state changed
			if (changes['wldt']) {
				fn(decodedObj(JSON.parse(changes['wldt'].oldValue)), decodedObj(JSON.parse(changes['wldt'].newValue)));
			};
		});
	}
});
},{}]},{},[2]);
