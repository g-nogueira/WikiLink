(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

const Events = require("../utils/Events")
module.exports = class Popover extends Events {
    constructor() {
        super();

        this.events = {
            popoverHidden: "popoverHidden"
        };
        this.iframeUrl;
        this.iframe;
        this.iframeStyle;
        this.shadowMode;
    }

    /**
     * Initializes DOM preferences
     *
     * @param {Object} options
     * @param {String} options.iframeUrl
     * @param {Number} options.iframeWidth
     * @param {Number} options.iframeHeight
     * @param {String} options.iframeStyle
     * @param {"open"|"closed"} options.shadowMode A string specifying the encapsulation mode for the shadow DOM tree
     * @returns
     */
    init(options) {
        this.iframeUrl = options.iframeUrl;
        this.shadowMode = options.shadowMode || "open";
        this.iframeStyle = options.iframeStyle || `
            width: ${options.iframeWidth || 501}px;
            height: ${options.iframeHeight || 276}px;
            border: none;
            z-index: 2139999998;
            box-shadow: 0 30px 90px -20px rgba(0, 0, 0, 0.3), 0 0 1px #a2a9b1;
        `;

        return this;
    }

    /**
     * Inserts an iframe into the DOM using the options specified on `init()` method.
     *
     */
    insertIframe() {
        let parentElement = document.createElement("div");
        let shadow = parentElement.attachShadow({ mode: this.shadowMode });
        let iframeNode = document.createElement("iframe");

        parentElement.classList.add("js-wikilink");
        parentElement.style = `
            position: absolute;
            background: transparent;
        `;

        iframeNode.style = this.iframeStyle;


        shadow.appendChild(iframeNode);
        document.body.appendChild(parentElement);

        let iframeElement = shadow.querySelector("iframe");
        iframeElement.parent = parentElement;

        this.iframe = iframeElement;
        this._dispatcher = iframeElement;
    }

    /**
     * Displays the iframe on the specified x,y coordinates.
     * 
     * @param {String} title
     * @param {Object} position
     * @param {Number} position.top
     * @param {Number} position.left
     * @param {Object} [options={}]
     * @param {Number} options.width
     * @param {Number} options.height
     */
    show(title, position, options = {}) {
        this.iframe.parent.style.top = position.top + "px";
        this.iframe.parent.style.left = position.left + "px";

        this.iframe.style.width = options.width || this.iframe.style.width;
        this.iframe.style.height = options.height || this.iframe.style.height;

        this.iframe.src = this.iframeUrl + "?title=" + title;

        this.iframe.classList.add("popover--enabled");
    }

    /**
     * Hides the iframe
     *
     * @param {*} options
     * @param {Number} [delay=300] A delay in milliseconds to hide the iframe.
     */
    hide(options, delay = 300) {
        setTimeout(() => {
            this.iframe.classList.remove("popover--enabled");
            this.dispatchEvent(this.events.popoverHidden, { element: this.iframe });
        }, delay);
    }

};
},{"../utils/Events":4}],2:[function(require,module,exports){
/*
#### DOM manipulation, data input and output ####
@------------------------------------------------@
| It creates a div element at the displayed page |
| DOM, as well as two "cals", for padding sakes. |
| Gets the ranges of these elements and listen to|
| the onmouseup event, that gets the selected    |
| text, parses it and request data to the API.   |
| The response will be displayed into a popover. |
@------------------------------------------------@
*/

(async function () {
	"use strict";

	const storageHelper = require("../utils/Storage");
	const shortcutHelper = require("../utils/Shortcut");
	const selectionHelper = require("../utils/Selection");
	const PopoverHelper = require("./Popover");
	const applicationSettings = new (require("../storageEntities/ApplicationSettings"));


	applicationSettings.getAll();
	let popoverInstance = new PopoverHelper();
	let userSettings = {
		isPopoverEnabled: await storageHelper.retrieve('isEnabled'),
		shortcut: await storageHelper.retrieve('shortcut')
	};


	// Initialize an iframe element and insert it into the DOM
	popoverInstance.init({
		iframeUrl: chrome.extension.getURL('pages/popoverGUI.html'),
		iframeStyle: applicationSettings.list.filter((el) => el.label === "modal.style")[0],
		shadowMode: applicationSettings.list.filter((el) => el.label === "modal.shadowMode")[0]
	});
	popoverInstance.insertIframe();


	// Listen for the shortcut to be triggered
	shortcutHelper.init(userSettings.shortcut);
	shortcutHelper.addEventListener("shortcutMatch", onShortcutMatch);

	// Listen for changes on storage
	storageHelper.onChanges(onStorageChange);



	function onShortcutMatch(ev) {
		let selectionObj = selectionHelper.getSelection();
		let selectionString = selectionObj.toString();
		let iframePosition = selectionHelper.getOffsetBottomPosition(selectionObj);

		if (userSettings.isPopoverEnabled && !selectionString.isCollapsed && !isEmptySelection(selectionString)) {
			popoverInstance.show(selectionString, iframePosition);
		}
	}

	function onStorageChange(oldV, newV) {
		shortcut = newV.shortcut;
		userSettings.isPopoverEnabled = newV.isEnabled;
		popoverInstance.shortcut = shortcut;
	}

	function isEmptySelection(selection) {
		//If given argument is not empty neither is white spaces
		return !(selection && /\S/.test(selection));
	}

}());
},{"../storageEntities/ApplicationSettings":3,"../utils/Selection":5,"../utils/Shortcut":6,"../utils/Storage":7,"./Popover":1}],3:[function(require,module,exports){

const Storage = require("../utils/Storage");

module.exports = class ApplicationSettings extends Storage {
    constructor() {

        super();

        this.storageName = "ApplicationSettings";
        this.label = "";
        this.value = "";
        this.description = "";
        this.modifiedOn = null;
    }

    async get(id) {
        let response = null;
        let applicationSettings = await this.retrieveStorage(this.storageName);

        if (!Array.isArray(applicationSettings) || !id) {
            return null;
        }

        let applicationSettingIndex = applicationSettings.findIndex((applicationSetting) => applicationSetting.id === id);

        if (applicationSettingIndex === -1) {
            return null;
        }

        response = applicationSettings[applicationSettingIndex];

        this.id = response.id;
        this.label = response.label;
        this.value = response.value;
        this.description = response.description;
        this.modifiedOn = response.modifiedOn;

        return response;
    }

    async update() {
        let response = null;
        let applicationSettings = await this.retrieveStorage(this.storageName);
        let localApplicationSetting = {
            id: this.id,
            label: this.label,
            value: this.value,
            description: this.description,
            modifiedOn: this.modifiedOn
        };

        if (!Array.isArray(applicationSettings) || applicationSettings.length === 0) {
            applicationSettings = [];
        }

        let applicationSettingIndex = applicationSettings.findIndex((applicationSetting) => applicationSetting.id === this.id);

        if (applicationSettingIndex === -1) {
            throw new Error("Application Setting not found.");
        }

        // Updates a user preference
        localApplicationSetting.modifiedOn = new Date();
        applicationSettings[applicationSettingIndex] = localApplicationSetting;

        response = await this.updateStorage(this.storageName, applicationSettings);

        return response;
    }

    async create() {
        let response = null;
        let applicationSettings = await this.retrieveStorage(this.storageName);
        let localApplicationSetting = {
            label: this.label,
            value: this.value,
            description: this.description,
            modifiedOn: null
        };

        if (!Array.isArray(applicationSettings) || applicationSettings.length === 0) {
            applicationSettings = [];
        }

        // Creates a user preference
        applicationSettings.push(localApplicationSetting);

        response = await this.updateStorage(this.storageName, applicationSettings);

        return response;
    }


};
},{"../utils/Storage":7}],4:[function(require,module,exports){
"use strict";

module.exports = class Events {

    /**
     * Creates an instance of Events.
     * @param {Object} [options={}]
     * @param {HTMLElement} [options.dispatcher]
     * @param {Object} options.events
     * 
     */
    constructor(options = {}) {
        this._dispatcher = options.dispatcher || document.createElement("div");
        this.events = options.events;


        this.shortcut = [];
    }

    /**
     * Dispatches a synthetic event to target and returns true if either event's cancelable attribute value is false or its preventDefault() method was not invoked, and false otherwise.
     *
     * @param {String} type
     * @param {Any} details Any custom data to be dispatch with the event.
     * @param {Boolean} canBubble A boolean indicating whether the event goes through its target's ancestors in reverse tree order.
     * @param {Boolean} cancelable A boolean indicating whether the event can be canceled by invoking the preventDefault() method.
     */
    dispatchEvent(type, details, canBubble = true, cancelable = true) {

        const event = new CustomEvent(type, {
            bubbles: canBubble,
            cancelable: cancelable,
            detail: details,
        })


        return this._dispatcher.dispatchEvent(event);
    }

    /**
     * Appends an event listener for events whose type attribute value is `type`. The callback argument sets the callback that will be invoked when the event is dispatched.
     *
     * @param {String} type
     * @param {(this: HTMLElement, ev: HTMLElementEventMap[K]) => any} eventListener
     * @return
     */
    addEventListener(type, eventListener) {
        this._dispatcher.addEventListener(type, eventListener);
    }

    get _shortcutMatchEvent() {
        return new CustomEvent("shortcutMatch", {
            bubbles: true,
            detail: {}
        });
    }

};
},{}],5:[function(require,module,exports){
(() => {
	"use strict";

	module.exports = new (class SelectionHelper {

		constructor() {
			this.selection = {};
		}

		/**
		 * Get the current selection.
		 *
		 * @returns {Selection}
		 */
		getSelection() {
			return window.getSelection();
		}

		/**
		 * Gets the ClientRect of a selection.
		 *
		 * @param {Selection} selection
		 * @returns {DOMRect}
		 */
		getSelectionPosition(selection) {

			var range = selection.getRangeAt(0);
			var DOMRect = range.getBoundingClientRect();

			return DOMRect;
		}

		/**
		 * Gets a ClientRect from the bottom left corner of a selection.
		 *
		 * @param {Selection} selection
		 * @returns {DOMRect}
		 */
		getOffsetBottomPosition(selection) {
			var temporaryNode = this._createUniqueNode();
			var temporaryNodeTop = 0;
			var range = selection.getRangeAt(0);
			var clientRect = range.getBoundingClientRect();

			// Insert a node at the start of the selection and get its position relative to the top of the body
			range.insertNode(temporaryNode);
			temporaryNodeTop = temporaryNode.offsetTop;

			// Determine the position below the selection as scrolledHeight (i.e.: temporaryNodeTop) + selectionHeight
			var position = new DOMRect(clientRect.x, clientRect.height + temporaryNodeTop, clientRect.width, clientRect.height);

			// Remove the previously inserted node
			temporaryNode.parentElement.removeChild(temporaryNode);

			return position;
		}


		_createUniqueNode() {
			var node = document.createElement("span");

			node.id = (new Date()).getTime();
			node.style.position = "absolute";

			return node;
		}

	});

})();
},{}],6:[function(require,module,exports){
"use strict";
const Events = require("./Events");
module.exports = new (class ShortcutHelper extends Events {

	constructor() {
		super();

		this.shortcut = [];
		this.events = {
			/** The `shortcutMatch` event is fired when a matching shortcut is pressed. */
			shortcutMatch: "shortcutMatch"
		};

	}

	/**
	 *
	 *
	 * @param {Array<String>} shortcut An array of key names
	 */
	init(shortcut) {
		this.shortcut = shortcut;

		var timeOutId = null;
		var keyGroup = [];
		var that = this;

		document.addEventListener("keydown", function onKeyDown(ev) {

			clearTimeout(timeOutId);

			if (keyGroup.toString() === shortcut.toString()) {

				that.dispatchEvent(that.events.shortcutMatch, { shortcut: shortcut });
				keyGroup = [];

			} else if (keyGroup.length < shortcut.length && !keyGroup.includes(ev.code)) {
				keyGroup.push(ev.code);
				onKeyDown(ev);
			}

			timeOutId = setTimeout(() => keyGroup = [], 10 * 1000);
		});

		document.addEventListener("keyup", function onKeyUp(ev) {
			var index = keyGroup.indexOf(ev.code);
			if (index !== -1) {
				keyGroup.splice(index, 1);
			}
		});
	}

});
},{"./Events":4}],7:[function(require,module,exports){
"use strict";


const Events = require("../utils/Events");

/**
 * Manages and facilitates storage (chrome.storage.sync) requests and watchers.
 */
module.exports = class StorageHelper extends Events {

	constructor() {
		super();

		this.storageName = "";
		this.list = [];
		this.events = {
			storageChange: "storageChange"
		};

		chrome.storage.onChanged.addListener((changes, areaName) => {

			if (this.storageName.length > 0 && changes[this.storageName]) {
				this.dispatchEvent(this.events.storageChange, {
					oldValue: changes[this.storageName].oldValue,
					newValue: changes[this.storageName].newValue
				});
			} else {
				this.dispatchEvent(this.events.storageChange, {
					oldValue: changes.oldValue,
					newValue: changes.newValue
				});
			}

		});

	}

	retrieveStorage(name) {
		return new Promise((resolve, reject) => {

			chrome.storage.sync.get(name, (obj) => {

				if (obj[name]) {
					resolve(obj[name]);
				}
				else {
					resolve(null);
				}

			});
		});
	}


	updateStorage(name, value) {
		return new Promise((resolve, reject) => {
			chrome.storage.sync.set({ [name]: value }, () => resolve(true));
		});
	}

	createStorage(name, value) {
		return new Promise((resolve, reject) => {
			chrome.storage.sync.set({ [name]: value }, () => resolve(true));
		});
	}

	async getAll() {
		let response = null;
		let storage = await this.retrieveStorage(this.storageName);

		if (!Array.isArray(storage)) {
			this.list = [];
			return null;
		}

		response = storage;
		this.list = response;

		return response;
	}
};
},{"../utils/Events":4}]},{},[2]);
