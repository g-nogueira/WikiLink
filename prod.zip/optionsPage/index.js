(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */
var byteToHex = [];

for (var i = 0; i < 256; ++i) {
  byteToHex[i] = (i + 0x100).toString(16).substr(1);
}

function bytesToUuid(buf, offset) {
  var i = offset || 0;
  var bth = byteToHex; // join used to fix memory issue caused by concatenation: https://bugs.chromium.org/p/v8/issues/detail?id=3175#c4

  return [bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]]].join('');
}

var _default = bytesToUuid;
exports.default = _default;
},{}],2:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "v1", {
  enumerable: true,
  get: function () {
    return _v.default;
  }
});
Object.defineProperty(exports, "v3", {
  enumerable: true,
  get: function () {
    return _v2.default;
  }
});
Object.defineProperty(exports, "v4", {
  enumerable: true,
  get: function () {
    return _v3.default;
  }
});
Object.defineProperty(exports, "v5", {
  enumerable: true,
  get: function () {
    return _v4.default;
  }
});

var _v = _interopRequireDefault(require("./v1.js"));

var _v2 = _interopRequireDefault(require("./v3.js"));

var _v3 = _interopRequireDefault(require("./v4.js"));

var _v4 = _interopRequireDefault(require("./v5.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
},{"./v1.js":6,"./v3.js":7,"./v4.js":9,"./v5.js":10}],3:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/*
 * Browser-compatible JavaScript MD5
 *
 * Modification of JavaScript MD5
 * https://github.com/blueimp/JavaScript-MD5
 *
 * Copyright 2011, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * https://opensource.org/licenses/MIT
 *
 * Based on
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Version 2.2 Copyright (C) Paul Johnston 1999 - 2009
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for more info.
 */
function md5(bytes) {
  if (typeof bytes == 'string') {
    var msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

    bytes = new Array(msg.length);

    for (var i = 0; i < msg.length; i++) bytes[i] = msg.charCodeAt(i);
  }

  return md5ToHexEncodedArray(wordsToMd5(bytesToWords(bytes), bytes.length * 8));
}
/*
 * Convert an array of little-endian words to an array of bytes
 */


function md5ToHexEncodedArray(input) {
  var i;
  var x;
  var output = [];
  var length32 = input.length * 32;
  var hexTab = '0123456789abcdef';
  var hex;

  for (i = 0; i < length32; i += 8) {
    x = input[i >> 5] >>> i % 32 & 0xff;
    hex = parseInt(hexTab.charAt(x >>> 4 & 0x0f) + hexTab.charAt(x & 0x0f), 16);
    output.push(hex);
  }

  return output;
}
/*
 * Calculate the MD5 of an array of little-endian words, and a bit length.
 */


function wordsToMd5(x, len) {
  /* append padding */
  x[len >> 5] |= 0x80 << len % 32;
  x[(len + 64 >>> 9 << 4) + 14] = len;
  var i;
  var olda;
  var oldb;
  var oldc;
  var oldd;
  var a = 1732584193;
  var b = -271733879;
  var c = -1732584194;
  var d = 271733878;

  for (i = 0; i < x.length; i += 16) {
    olda = a;
    oldb = b;
    oldc = c;
    oldd = d;
    a = md5ff(a, b, c, d, x[i], 7, -680876936);
    d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
    c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
    b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
    a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
    d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
    c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
    b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
    a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
    d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
    c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
    b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
    a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
    d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
    c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
    b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
    a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
    d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
    c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
    b = md5gg(b, c, d, a, x[i], 20, -373897302);
    a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
    d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
    c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
    b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
    a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
    d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
    c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
    b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
    a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
    d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
    c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
    b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
    a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
    d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
    c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
    b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
    a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
    d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
    c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
    b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
    a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
    d = md5hh(d, a, b, c, x[i], 11, -358537222);
    c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
    b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
    a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
    d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
    c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
    b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
    a = md5ii(a, b, c, d, x[i], 6, -198630844);
    d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
    c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
    b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
    a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
    d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
    c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
    b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
    a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
    d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
    c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
    b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
    a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
    d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
    c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
    b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
    a = safeAdd(a, olda);
    b = safeAdd(b, oldb);
    c = safeAdd(c, oldc);
    d = safeAdd(d, oldd);
  }

  return [a, b, c, d];
}
/*
 * Convert an array bytes to an array of little-endian words
 * Characters >255 have their high-byte silently ignored.
 */


function bytesToWords(input) {
  var i;
  var output = [];
  output[(input.length >> 2) - 1] = undefined;

  for (i = 0; i < output.length; i += 1) {
    output[i] = 0;
  }

  var length8 = input.length * 8;

  for (i = 0; i < length8; i += 8) {
    output[i >> 5] |= (input[i / 8] & 0xff) << i % 32;
  }

  return output;
}
/*
 * Add integers, wrapping at 2^32. This uses 16-bit operations internally
 * to work around bugs in some JS interpreters.
 */


function safeAdd(x, y) {
  var lsw = (x & 0xffff) + (y & 0xffff);
  var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
  return msw << 16 | lsw & 0xffff;
}
/*
 * Bitwise rotate a 32-bit number to the left.
 */


function bitRotateLeft(num, cnt) {
  return num << cnt | num >>> 32 - cnt;
}
/*
 * These functions implement the four basic operations the algorithm uses.
 */


function md5cmn(q, a, b, x, s, t) {
  return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
}

function md5ff(a, b, c, d, x, s, t) {
  return md5cmn(b & c | ~b & d, a, b, x, s, t);
}

function md5gg(a, b, c, d, x, s, t) {
  return md5cmn(b & d | c & ~d, a, b, x, s, t);
}

function md5hh(a, b, c, d, x, s, t) {
  return md5cmn(b ^ c ^ d, a, b, x, s, t);
}

function md5ii(a, b, c, d, x, s, t) {
  return md5cmn(c ^ (b | ~d), a, b, x, s, t);
}

var _default = md5;
exports.default = _default;
},{}],4:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = rng;
// Unique ID creation requires a high quality random # generator. In the browser we therefore
// require the crypto API and do not support built-in fallback to lower quality random number
// generators (like Math.random()).
// getRandomValues needs to be invoked in a context where "this" is a Crypto implementation. Also,
// find the complete implementation of crypto (msCrypto) on IE11.
var getRandomValues = typeof crypto != 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto != 'undefined' && typeof msCrypto.getRandomValues == 'function' && msCrypto.getRandomValues.bind(msCrypto);
var rnds8 = new Uint8Array(16); // eslint-disable-line no-undef

function rng() {
  if (!getRandomValues) {
    throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
  }

  return getRandomValues(rnds8);
}
},{}],5:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

// Adapted from Chris Veness' SHA1 code at
// http://www.movable-type.co.uk/scripts/sha1.html
function f(s, x, y, z) {
  switch (s) {
    case 0:
      return x & y ^ ~x & z;

    case 1:
      return x ^ y ^ z;

    case 2:
      return x & y ^ x & z ^ y & z;

    case 3:
      return x ^ y ^ z;
  }
}

function ROTL(x, n) {
  return x << n | x >>> 32 - n;
}

function sha1(bytes) {
  var K = [0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6];
  var H = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0];

  if (typeof bytes == 'string') {
    var msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

    bytes = new Array(msg.length);

    for (var i = 0; i < msg.length; i++) bytes[i] = msg.charCodeAt(i);
  }

  bytes.push(0x80);
  var l = bytes.length / 4 + 2;
  var N = Math.ceil(l / 16);
  var M = new Array(N);

  for (var i = 0; i < N; i++) {
    M[i] = new Array(16);

    for (var j = 0; j < 16; j++) {
      M[i][j] = bytes[i * 64 + j * 4] << 24 | bytes[i * 64 + j * 4 + 1] << 16 | bytes[i * 64 + j * 4 + 2] << 8 | bytes[i * 64 + j * 4 + 3];
    }
  }

  M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);
  M[N - 1][14] = Math.floor(M[N - 1][14]);
  M[N - 1][15] = (bytes.length - 1) * 8 & 0xffffffff;

  for (var i = 0; i < N; i++) {
    var W = new Array(80);

    for (var t = 0; t < 16; t++) W[t] = M[i][t];

    for (var t = 16; t < 80; t++) {
      W[t] = ROTL(W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16], 1);
    }

    var a = H[0];
    var b = H[1];
    var c = H[2];
    var d = H[3];
    var e = H[4];

    for (var t = 0; t < 80; t++) {
      var s = Math.floor(t / 20);
      var T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[t] >>> 0;
      e = d;
      d = c;
      c = ROTL(b, 30) >>> 0;
      b = a;
      a = T;
    }

    H[0] = H[0] + a >>> 0;
    H[1] = H[1] + b >>> 0;
    H[2] = H[2] + c >>> 0;
    H[3] = H[3] + d >>> 0;
    H[4] = H[4] + e >>> 0;
  }

  return [H[0] >> 24 & 0xff, H[0] >> 16 & 0xff, H[0] >> 8 & 0xff, H[0] & 0xff, H[1] >> 24 & 0xff, H[1] >> 16 & 0xff, H[1] >> 8 & 0xff, H[1] & 0xff, H[2] >> 24 & 0xff, H[2] >> 16 & 0xff, H[2] >> 8 & 0xff, H[2] & 0xff, H[3] >> 24 & 0xff, H[3] >> 16 & 0xff, H[3] >> 8 & 0xff, H[3] & 0xff, H[4] >> 24 & 0xff, H[4] >> 16 & 0xff, H[4] >> 8 & 0xff, H[4] & 0xff];
}

var _default = sha1;
exports.default = _default;
},{}],6:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _rng = _interopRequireDefault(require("./rng.js"));

var _bytesToUuid = _interopRequireDefault(require("./bytesToUuid.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// **`v1()` - Generate time-based UUID**
//
// Inspired by https://github.com/LiosK/UUID.js
// and http://docs.python.org/library/uuid.html
var _nodeId;

var _clockseq; // Previous uuid creation time


var _lastMSecs = 0;
var _lastNSecs = 0; // See https://github.com/uuidjs/uuid for API details

function v1(options, buf, offset) {
  var i = buf && offset || 0;
  var b = buf || [];
  options = options || {};
  var node = options.node || _nodeId;
  var clockseq = options.clockseq !== undefined ? options.clockseq : _clockseq; // node and clockseq need to be initialized to random values if they're not
  // specified.  We do this lazily to minimize issues related to insufficient
  // system entropy.  See #189

  if (node == null || clockseq == null) {
    var seedBytes = options.random || (options.rng || _rng.default)();

    if (node == null) {
      // Per 4.5, create and 48-bit node id, (47 random bits + multicast bit = 1)
      node = _nodeId = [seedBytes[0] | 0x01, seedBytes[1], seedBytes[2], seedBytes[3], seedBytes[4], seedBytes[5]];
    }

    if (clockseq == null) {
      // Per 4.2.2, randomize (14 bit) clockseq
      clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 0x3fff;
    }
  } // UUID timestamps are 100 nano-second units since the Gregorian epoch,
  // (1582-10-15 00:00).  JSNumbers aren't precise enough for this, so
  // time is handled internally as 'msecs' (integer milliseconds) and 'nsecs'
  // (100-nanoseconds offset from msecs) since unix epoch, 1970-01-01 00:00.


  var msecs = options.msecs !== undefined ? options.msecs : new Date().getTime(); // Per 4.2.1.2, use count of uuid's generated during the current clock
  // cycle to simulate higher resolution clock

  var nsecs = options.nsecs !== undefined ? options.nsecs : _lastNSecs + 1; // Time since last uuid creation (in msecs)

  var dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 10000; // Per 4.2.1.2, Bump clockseq on clock regression

  if (dt < 0 && options.clockseq === undefined) {
    clockseq = clockseq + 1 & 0x3fff;
  } // Reset nsecs if clock regresses (new clockseq) or we've moved onto a new
  // time interval


  if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === undefined) {
    nsecs = 0;
  } // Per 4.2.1.2 Throw error if too many uuids are requested


  if (nsecs >= 10000) {
    throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
  }

  _lastMSecs = msecs;
  _lastNSecs = nsecs;
  _clockseq = clockseq; // Per 4.1.4 - Convert from unix epoch to Gregorian epoch

  msecs += 12219292800000; // `time_low`

  var tl = ((msecs & 0xfffffff) * 10000 + nsecs) % 0x100000000;
  b[i++] = tl >>> 24 & 0xff;
  b[i++] = tl >>> 16 & 0xff;
  b[i++] = tl >>> 8 & 0xff;
  b[i++] = tl & 0xff; // `time_mid`

  var tmh = msecs / 0x100000000 * 10000 & 0xfffffff;
  b[i++] = tmh >>> 8 & 0xff;
  b[i++] = tmh & 0xff; // `time_high_and_version`

  b[i++] = tmh >>> 24 & 0xf | 0x10; // include version

  b[i++] = tmh >>> 16 & 0xff; // `clock_seq_hi_and_reserved` (Per 4.2.2 - include variant)

  b[i++] = clockseq >>> 8 | 0x80; // `clock_seq_low`

  b[i++] = clockseq & 0xff; // `node`

  for (var n = 0; n < 6; ++n) {
    b[i + n] = node[n];
  }

  return buf ? buf : (0, _bytesToUuid.default)(b);
}

var _default = v1;
exports.default = _default;
},{"./bytesToUuid.js":1,"./rng.js":4}],7:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _v = _interopRequireDefault(require("./v35.js"));

var _md = _interopRequireDefault(require("./md5.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const v3 = (0, _v.default)('v3', 0x30, _md.default);
var _default = v3;
exports.default = _default;
},{"./md5.js":3,"./v35.js":8}],8:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;
exports.URL = exports.DNS = void 0;

var _bytesToUuid = _interopRequireDefault(require("./bytesToUuid.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function uuidToBytes(uuid) {
  // Note: We assume we're being passed a valid uuid string
  var bytes = [];
  uuid.replace(/[a-fA-F0-9]{2}/g, function (hex) {
    bytes.push(parseInt(hex, 16));
  });
  return bytes;
}

function stringToBytes(str) {
  str = unescape(encodeURIComponent(str)); // UTF8 escape

  var bytes = new Array(str.length);

  for (var i = 0; i < str.length; i++) {
    bytes[i] = str.charCodeAt(i);
  }

  return bytes;
}

const DNS = '6ba7b810-9dad-11d1-80b4-00c04fd430c8';
exports.DNS = DNS;
const URL = '6ba7b811-9dad-11d1-80b4-00c04fd430c8';
exports.URL = URL;

function _default(name, version, hashfunc) {
  var generateUUID = function (value, namespace, buf, offset) {
    var off = buf && offset || 0;
    if (typeof value == 'string') value = stringToBytes(value);
    if (typeof namespace == 'string') namespace = uuidToBytes(namespace);
    if (!Array.isArray(value)) throw TypeError('value must be an array of bytes');
    if (!Array.isArray(namespace) || namespace.length !== 16) throw TypeError('namespace must be uuid string or an Array of 16 byte values'); // Per 4.3

    var bytes = hashfunc(namespace.concat(value));
    bytes[6] = bytes[6] & 0x0f | version;
    bytes[8] = bytes[8] & 0x3f | 0x80;

    if (buf) {
      for (var idx = 0; idx < 16; ++idx) {
        buf[off + idx] = bytes[idx];
      }
    }

    return buf || (0, _bytesToUuid.default)(bytes);
  }; // Function#name is not settable on some platforms (#270)


  try {
    generateUUID.name = name;
  } catch (err) {} // For CommonJS default export support


  generateUUID.DNS = DNS;
  generateUUID.URL = URL;
  return generateUUID;
}
},{"./bytesToUuid.js":1}],9:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _rng = _interopRequireDefault(require("./rng.js"));

var _bytesToUuid = _interopRequireDefault(require("./bytesToUuid.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function v4(options, buf, offset) {
  var i = buf && offset || 0;

  if (typeof options == 'string') {
    buf = options === 'binary' ? new Array(16) : null;
    options = null;
  }

  options = options || {};

  var rnds = options.random || (options.rng || _rng.default)(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`


  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  if (buf) {
    for (var ii = 0; ii < 16; ++ii) {
      buf[i + ii] = rnds[ii];
    }
  }

  return buf || (0, _bytesToUuid.default)(rnds);
}

var _default = v4;
exports.default = _default;
},{"./bytesToUuid.js":1,"./rng.js":4}],10:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _v = _interopRequireDefault(require("./v35.js"));

var _sha = _interopRequireDefault(require("./sha1.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const v5 = (0, _v.default)('v5', 0x50, _sha.default);
var _default = v5;
exports.default = _default;
},{"./sha1.js":5,"./v35.js":8}],11:[function(require,module,exports){
(function () {
	'use strict';
	/**
	 * Shorthand function for querySelector
	 * @param {string} el 
	 * @returns {HTMLElement} 
	 */
	const DOM = elem => document.body.querySelector(elem);

	const userPreferences = new (require("../storageEntities/UserPreferences"));
	const applicationSettings = new (require("../storageEntities/ApplicationSettings"));
	const shortcutHelper = require("../utils/Shortcut");

	initialization();
	watchShortcutInput();
	watchFormChange();

	////////////////// IMPLEMENTATION //////////////////

	/**
	 * Initializes the necessary first load data.
	 */
	async function initialization() {
		await applicationSettings.getAll();
		await userPreferences.getAll();

		applicationSettings.list.forEach((el) => {
			let id = `#${el.label.replace(".", "_")}`;

			if (!DOM(id)) {
				return;
			}
			DOM(id).value = el.value;
		});

		userPreferences.list.forEach((el) => {
			let id = `#${el.label.replace(".", "_")}`;

			if (!DOM(id)) {
				return;
			}
			DOM(id).value = el.value;
		});
	}

	/**
	 * Handles the shortcut input field functionalities.
	 */
	function watchShortcutInput() {

		var input = DOM("#shortcuts_toggleModal");

		// 1. On focusin empties the input 
		input.addEventListener("focusin", (ev) => {
			input.dataset.keyGroupDown = input.value;
			input.value = "";
		});

		// 2. On keydown sets the keys pressed
		shortcutHelper.addEventListener(shortcutHelper.events.keyGroupDown, (ev) => {
			if (ev.detail.ev.target !== input) {
				return;
			}

			if (ev.detail.keyGroup.length < input.value.split(",").length) {
				return;
			}

			input.value = ev.detail.keyGroup;
		});

		// 3. On focusout rollback to original value, if empty
		input.addEventListener("focusout", (ev) => {
			if (input.value !== "") {
				// Manually triggers change event, else it won't trigger 
				DOM("#form_userPreferences").dispatchEvent(new Event("change"));
				return;
			}

			input.value = input.dataset.keyGroupDown;
		});
	}

	/**
	 * Saves updates to forms.
	 */
	function watchFormChange() {
		var formApplicationSettings = DOM("#form_applicationSettings");
		var formUserPreferences = DOM("#form_userPreferences");

		formApplicationSettings.addEventListener("change", async (ev) => {
			for (const el of formApplicationSettings.elements) {

				let label = el.id.replace("_", ".");
				await applicationSettings.get(label);

				applicationSettings.value = el.value;
				applicationSettings.modifiedOn = new Date();
				await applicationSettings.update();
			}
		});

		formUserPreferences.addEventListener("change", async (ev) => {
			for (const el of formUserPreferences.elements) {

				let label = el.id.replace("_", ".");
				await userPreferences.get(label);

				userPreferences.value = el.value;
				userPreferences.modifiedOn = new Date();
				await userPreferences.update();
			}
		});
	}

}());
},{"../storageEntities/ApplicationSettings":12,"../storageEntities/UserPreferences":13,"../utils/Shortcut":15}],12:[function(require,module,exports){

const Storage = require("../utils/Storage");

module.exports = class ApplicationSettings extends Storage {
    constructor() {

        super();

        this.storageName = "ApplicationSettings";
        this.label = "";
        this.value = "";
        this.description = "";
        this.modifiedOn = null;
    }

    async get(label) {
        let response = null;
        let applicationSettings = await this.retrieveStorage(this.storageName);

        if (!Array.isArray(applicationSettings) || !label) {
            return null;
        }

        let applicationSettingIndex = applicationSettings.findIndex((applicationSetting) => applicationSetting.label === label);

        if (applicationSettingIndex === -1) {
            return null;
        }

        response = applicationSettings[applicationSettingIndex];

        this.label = response.label;
        this.value = response.value;
        this.description = response.description;
        this.modifiedOn = response.modifiedOn;

        return response;
    }

    async update() {
        let response = null;
        let applicationSettings = await this.retrieveStorage(this.storageName);
        let localApplicationSetting = {
            label: this.label,
            value: this.value,
            description: this.description,
            modifiedOn: this.modifiedOn
        };

        if (!Array.isArray(applicationSettings) || applicationSettings.length === 0) {
            applicationSettings = [];
        }

        let applicationSettingIndex = applicationSettings.findIndex((applicationSetting) => applicationSetting.label === this.label);

        if (applicationSettingIndex === -1) {
            throw new Error("Application Setting not found.");
        }

        // Updates a user preference
        localApplicationSetting.modifiedOn = new Date();
        applicationSettings[applicationSettingIndex] = localApplicationSetting;

        response = await this.updateStorage(this.storageName, applicationSettings);

        return response;
    }

    async create() {
        let response = null;
        let applicationSettings = await this.retrieveStorage(this.storageName);
        let localApplicationSetting = {
            label: this.label,
            value: this.value,
            description: this.description,
            modifiedOn: null
        };

        if (!Array.isArray(applicationSettings) || applicationSettings.length === 0) {
            applicationSettings = [];
        }

        // Creates a user preference
        applicationSettings.push(localApplicationSetting);

        response = await this.updateStorage(this.storageName, applicationSettings);

        return response;
    }


};
},{"../utils/Storage":16}],13:[function(require,module,exports){

const Storage = require("../utils/Storage");
const uuid = require("uuid");

module.exports = class UserPreferences extends Storage {
    constructor() {

        super();

        this.storageName = "UserPreferences";
        this.label = "";
        this.value = "";
        this.description = "";
        this.disabled = false;
        this.modifiedOn = null;
    }

    async get(label) {
        let response = null;
        let userPreferences = await this.retrieveStorage(this.storageName);

        if (!Array.isArray(userPreferences) || !label) {
            return null;
        }

        let applicationSettingIndex = userPreferences.findIndex((applicationSetting) => applicationSetting.label === label);

        if (applicationSettingIndex === -1) {
            return null;
        }

        response = userPreferences[applicationSettingIndex];

        this.label = response.label;
        this.value = response.value;
        this.description = response.description;
        this.disabled = response.disabled;
        this.modifiedOn = response.modifiedOn;

        return response;
    }

    async create() {
        let response = null;
        let userPreferences = await this.retrieveStorage(this.storageName);
        let localUserPreference = {
            label: this.label,
            value: this.value,
            description: this.description,
            disabled: this.disabled,
            modifiedOn: null
        };

        if (!Array.isArray(userPreferences) || userPreferences.length === 0) {
            userPreferences = [];
        }

        // Creates a user preference
        userPreferences.push(localUserPreference);

        response = await this.updateStorage(this.storageName, userPreferences);

        return response;
    }

    async update() {
        let response = null;
        let applicationSettings = await this.retrieveStorage(this.storageName);
        let localUserPreference = {
            label: this.label,
            value: this.value,
            description: this.description,
            disabled: this.disabled,
            modifiedOn: this.modifiedOn
        };

        if (!Array.isArray(applicationSettings) || applicationSettings.length === 0) {
            applicationSettings = [];
        }

        let applicationSettingIndex = applicationSettings.findIndex((applicationSetting) => applicationSetting.label === this.label);

        if (applicationSettingIndex === -1) {
            throw new Error("Application Setting not found.");
        }

        // Updates a user preference
        localUserPreference.modifiedOn = new Date();
        applicationSettings[applicationSettingIndex] = localUserPreference;

        response = await this.updateStorage(this.storageName, applicationSettings);

        return response;
    }


};
},{"../utils/Storage":16,"uuid":2}],14:[function(require,module,exports){
"use strict";

module.exports = class Events {

    /**
     * Creates an instance of Events.
     * @param {Object} [options={}]
     * @param {HTMLElement} [options.dispatcher]
     * @param {Object} options.events
     * 
     */
    constructor(options = {}) {
        this._dispatcher = options.dispatcher || document.createElement("div");
        this.events = options.events;


        this.shortcut = [];
    }

    /**
     * Dispatches a synthetic event to target and returns true if either event's cancelable attribute value is false or its preventDefault() method was not invoked, and false otherwise.
     *
     * @param {String} type
     * @param {Any} details Any custom data to be dispatch with the event.
     * @param {Event} ev The parent event, if any.
     * @param {Boolean} canBubble A boolean indicating whether the event goes through its target's ancestors in reverse tree order.
     * @param {Boolean} cancelable A boolean indicating whether the event can be canceled by invoking the preventDefault() method.
     */
    dispatchEvent(type, details, ev = null, canBubble = true, cancelable = true) {

        var _details = details;

        if (ev !== null) {
            _details.ev = ev;
        }

        const event = new CustomEvent(type, {
            bubbles: canBubble,
            cancelable: cancelable,
            detail: _details,
        })


        return this._dispatcher.dispatchEvent(event);
    }

    /**
     * Appends an event listener for events whose type attribute value is `type`. The callback argument sets the callback that will be invoked when the event is dispatched.
     *
     * @param {String} type
     * @param {(this: HTMLElement, ev: HTMLElementEventMap[K]) => any} eventListener
     * @return
     */
    addEventListener(type, eventListener) {
        this._dispatcher.addEventListener(type, eventListener);
    }

    get _shortcutMatchEvent() {
        return new CustomEvent("shortcutMatch", {
            bubbles: true,
            detail: {}
        });
    }

};
},{}],15:[function(require,module,exports){
"use strict";
const Events = require("./Events");
module.exports = new (class ShortcutHelper extends Events {

	constructor() {
		super();

		/** @type  {Array<String[]>}*/
		this.shortcut = [];
		this.events = {
			/** The `shortcutMatch` event is fired when a matching shortcut is pressed. */
			shortcutMatch: "shortcutMatch",
			/** The `keyGroupDown` event is fired when a group of keys are pressed. */
			keyGroupDown: "keyGroupDown"
		};

		this.init();

	}

	/**
	 *
	 *
	 * @param {Array<String>} shortcut An array of key names
	 */
	init() {
		this._bootstrapShortcutMatchEvent();
		this._bootstrapKeyDownEvent();
	}


	_bootstrapShortcutMatchEvent() {
		var timeOutId = null;
		var keyPressingGroung = [];
		var that = this;


		document.addEventListener("keydown", function onKeyDown(ev) {

			if (that.shortcut.length === 0) {
				return;
			}

			let shortcut = that.shortcut.filter((sc) => keyPressingGroung.toString() === sc.toString());
			let keyDown = ev.code;

			clearTimeout(timeOutId);

			if (shortcut.length > 0) {

				// Dispatch shortcutMatch event
				that.dispatchEvent(that.events.shortcutMatch, { shortcut: shortcut[0] }, ev);
				keyPressingGroung = [];

			} else if (!keyPressingGroung.includes(keyDown)) {

				// Add another key keyPressingGroung
				keyPressingGroung.push(keyDown);
				onKeyDown(ev);
			}

			// Clears in 10 seconds the current pressed shortcut
			timeOutId = setTimeout(() => keyPressingGroung = [], 10 * 1000);
		});

		document.addEventListener("keyup", function onKeyUp(ev) {
			let keyDown = ev.code;
			let index = keyPressingGroung.indexOf(keyDown);
			if (index !== -1) {
				keyPressingGroung.splice(index, 1);
			}
		});
	}

	_bootstrapKeyDownEvent() {
		var timeOutId = null;
		var keyPressingGroung = [];
		var that = this;


		document.addEventListener("keydown", function onKeyDown(ev) {

			// Resets the clear timer
			clearTimeout(timeOutId);
			let keyDown = ev.code;


			// Add another key keyPressingGroung
			if (!keyPressingGroung.includes(keyDown)) {

				keyPressingGroung.push(keyDown);
				that.dispatchEvent(that.events.keyGroupDown, { keyGroup: keyPressingGroung }, ev);
				onKeyDown(ev);
			}

			// Clears the current pressed group in 10 seconds
			timeOutId = setTimeout(() => keyPressingGroung = [], 10 * 1000);
		});

		document.addEventListener("keyup", function onKeyUp(ev) {
			let keyDown = ev.code;
			let index = keyPressingGroung.indexOf(keyDown);
			if (index !== -1) {
				keyPressingGroung.splice(index, 1);
				that.dispatchEvent(that.events.keyGroupDown, { keyGroup: keyPressingGroung }, ev);
			}
		});
	}

});
},{"./Events":14}],16:[function(require,module,exports){
const Events = require("../utils/Events");

/**
 * Manages and facilitates storage (chrome.storage.sync) requests and watchers.
 */
module.exports = class StorageHelper extends Events {

	constructor() {
		super();

		this.storageName = "";
		this.list = [];
		this.events = {
			storageChange: "storageChange"
		};

		chrome.storage.onChanged.addListener((changes, areaName) => {

			if (this.storageName.length > 0 && changes[this.storageName]) {
				this.dispatchEvent(this.events.storageChange, {
					oldValue: changes[this.storageName].oldValue,
					newValue: changes[this.storageName].newValue
				});
			} else {
				this.dispatchEvent(this.events.storageChange, {
					oldValue: changes.oldValue,
					newValue: changes.newValue
				});
			}

		});

	}

	retrieveStorage(name) {
		return new Promise((resolve, reject) => {

			chrome.storage.sync.get(name, (obj) => {

				if (obj[name]) {
					resolve(obj[name]);
				}
				else {
					resolve(null);
				}

			});
		});
	}


	updateStorage(name, value) {
		return new Promise((resolve, reject) => {
			chrome.storage.sync.set({ [name]: value }, () => resolve(true));
		});
	}

	createStorage(name, value) {
		return new Promise((resolve, reject) => {
			chrome.storage.sync.set({ [name]: value }, () => resolve(true));
		});
	}

	async getAll() {
		let response = null;
		let storage = await this.retrieveStorage(this.storageName);

		if (!Array.isArray(storage)) {
			this.list = [];
			return null;
		}

		response = storage;
		this.list = response;

		return response;
	}
};
},{"../utils/Events":14}]},{},[11]);
